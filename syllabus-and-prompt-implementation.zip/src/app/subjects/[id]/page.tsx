"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { useUI } from "@/components/Dialogs";
import { ChapterRow } from "@/components/Domain";
import { AddChapterDialog, ImportSyllabusDialog } from "@/components/SyllabusTools";
import { Badge, Button, Card, EmptyState, Field, PageHeader, ProgressBar, SectionTitle } from "@/components/ui";
import { useStore } from "@/lib/store";
import { fmtShort, pct, revisionBucket, subjectStats, todayStr, weakReasons } from "@/lib/utils";

export default function SubjectPage() {
  const params = useParams<{ id: string }>();
  const { data, actions } = useStore();
  const { openRevision, openPractice, openTask, openChapter, toast } = useUI();
  const subject = data.subjects.find((s) => s.id === params.id);
  const [dlg, setDlg] = useState<"import" | "add" | null>(null);
  const [notes, setNotes] = useState(subject?.notes ?? "");
  const [comp, setComp] = useState("");
  useEffect(() => setNotes(subject?.notes ?? ""), [subject?.id, subject?.notes]);

  const chapters = useMemo(() => data.chapters.filter((c) => c.subjectId === params.id).sort((a, b) => a.order - b.order), [data.chapters, params.id]);
  const groups = useMemo(() => {
    const map = new Map<string, typeof chapters>();
    chapters.forEach((c) => map.set(c.unit || "", [...(map.get(c.unit || "") ?? []), c]));
    return [...map.entries()];
  }, [chapters]);

  if (!subject) {
    return (
      <EmptyState title="Subject not found" action={<Link href="/subjects" className="text-sm font-medium text-accent">Back to subjects</Link>} />
    );
  }
  const st = subjectStats(subject.id, data.chapters);
  const today = todayStr();
  const weak = chapters.filter((c) => weakReasons(c, data.practice).length > 0);
  const recent = [...chapters].filter((c) => c.lastStudied).sort((a, b) => (b.lastStudied! > a.lastStudied! ? 1 : -1)).slice(0, 4);
  const revs = data.revisions.filter((r) => r.subjectId === subject.id && !r.done).sort((a, b) => (a.date < b.date ? -1 : 1)).slice(0, 5);
  const mathTotals = chapters.reduce(
    (a, c) => ({ attempted: a.attempted + c.math.attempted, correct: a.correct + c.math.correct, difficult: a.difficult + c.math.difficult }),
    { attempted: 0, correct: 0, difficult: 0 },
  );

  return (
    <div className="space-y-6">
      <Link href="/subjects" className="text-[13px] text-muted hover:text-fg">← All subjects</Link>
      <PageHeader
        title={subject.name}
        subtitle="Chapters are tracked equally toward this subject’s completion."
        actions={
          <>
            <Button onClick={() => openTask({ subjectId: subject.id })}>＋ Plan session</Button>
            <Button onClick={() => setDlg("add")}>＋ Add chapter</Button>
            <Button variant="primary" onClick={() => setDlg("import")}>⇪ Import syllabus</Button>
          </>
        }
      />

      <Card className="p-5">
        <div className="mb-3 flex items-end justify-between">
          <p className="text-3xl font-semibold tabular-nums">{st.total ? `${st.percent}%` : "—"}</p>
          <p className="text-sm text-muted">{st.total ? `${st.completed} / ${st.total} chapters completed` : "No chapters yet"}</p>
        </div>
        <ProgressBar value={st.percent} label="Subject progress" className="!h-3" />
        <dl className="mt-4 grid grid-cols-2 gap-3 text-center sm:grid-cols-5">
          {[
            ["Total", st.total],
            ["Completed", st.completed],
            ["Remaining", st.remaining],
            ["In progress", st.inProgress],
            ["Needs revision", st.needsRevision],
          ].map(([l, v]) => (
            <div key={l} className="rounded-xl bg-surface2 py-3">
              <dd className="text-xl font-semibold tabular-nums">{v}</dd>
              <dt className="text-xs text-muted">{l}</dt>
            </div>
          ))}
        </dl>
      </Card>

      <section>
        <SectionTitle>Chapters</SectionTitle>
        {chapters.length === 0 ? (
          <EmptyState
            title="Syllabus not imported yet"
            text="Paste the chapter list for this subject from your SEBA syllabus PDF, or add chapters one at a time. Nothing is pre-filled so only official names are used."
            action={
              <div className="flex gap-2">
                <Button variant="primary" onClick={() => setDlg("import")}>Import syllabus</Button>
                <Button onClick={() => setDlg("add")}>Add chapter</Button>
              </div>
            }
          />
        ) : (
          <div className="space-y-5">
            {groups.map(([unit, list]) => (
              <div key={unit || "none"}>
                {(unit || groups.length > 1) && <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">{unit || "Other chapters"}</h3>}
                <div className="space-y-2">
                  {list.map((c) => (
                    <ChapterRow key={c.id} chapter={c} expandable />
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {subject.kind === "math" && (
        <Card className="p-4">
          <SectionTitle>Practice tracking (from chapter records)</SectionTitle>
          <dl className="grid grid-cols-2 gap-3 text-center sm:grid-cols-4">
            <Stat l="Attempted" v={mathTotals.attempted} />
            <Stat l="Correct" v={mathTotals.correct} />
            <Stat l="Accuracy" v={mathTotals.attempted ? `${pct(mathTotals.correct, mathTotals.attempted)}%` : "—"} />
            <Stat l="Found difficult" v={mathTotals.difficult} />
          </dl>
          {chapters.some((c) => c.math.needsPractice.trim()) && (
            <div className="mt-3 text-[13px]">
              <p className="mb-1 font-medium">Topics needing more practice</p>
              <ul className="list-disc space-y-0.5 pl-5 text-muted">
                {chapters.filter((c) => c.math.needsPractice.trim()).map((c) => (
                  <li key={c.id}>
                    <strong className="text-fg">{c.name}:</strong> {c.math.needsPractice}
                  </li>
                ))}
              </ul>
            </div>
          )}
          <p className="mt-3 text-xs text-muted">Edit a chapter to update its attempted / correct / difficult counts.</p>
        </Card>
      )}

      {subject.kind !== "math" && (
        <Card className="p-4">
          <SectionTitle>Tracked components</SectionTitle>
          {subject.kind === "language" && (
            <p className="mb-3 text-[13px] text-muted">Add only the components your syllabus defines (e.g. reading, grammar, literature). None are assumed.</p>
          )}
          <div className="mb-3 flex flex-wrap gap-2">
            {subject.components.length === 0 && <span className="text-[13px] text-muted">No components yet.</span>}
            {subject.components.map((c) => {
              const done = chapters.filter((ch) => ch.components[c]).length;
              return (
                <Badge key={c} tone="accent" className="!py-1.5">
                  {c}: {done}/{chapters.length}
                  <button
                    aria-label={`Remove component ${c}`}
                    className="ml-1 opacity-70 hover:opacity-100"
                    onClick={() => actions.updateSubject(subject.id, { components: subject.components.filter((x) => x !== c) })}
                  >
                    ✕
                  </button>
                </Badge>
              );
            })}
          </div>
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              const v = comp.trim();
              if (!v) return;
              if (subject.components.includes(v)) return toast("Component already exists", "error");
              actions.updateSubject(subject.id, { components: [...subject.components, v] });
              setComp("");
              toast("Component added");
            }}
          >
            <input className="input" aria-label="New component name" placeholder="Add component (e.g. Grammar)" value={comp} onChange={(e) => setComp(e.target.value)} />
            <Button type="submit">Add</Button>
          </form>
          <p className="mt-2 text-xs text-muted">Tick components per chapter inside the chapter editor.</p>
        </Card>
      )}

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="p-4">
          <SectionTitle>Weak chapters ({weak.length})</SectionTitle>
          {weak.length === 0 ? <p className="text-[13px] text-muted">None right now.</p> : (
            <ul className="space-y-2">
              {weak.map((c) => (
                <li key={c.id}>
                  <button className="text-left text-sm font-medium hover:text-accent" onClick={() => openChapter(c.id)}>{c.name}</button>
                  <p className="text-xs text-muted">{weakReasons(c, data.practice).join(" · ")}</p>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card className="p-4">
          <SectionTitle>Recently studied</SectionTitle>
          {recent.length === 0 ? <p className="text-[13px] text-muted">Nothing yet.</p> : (
            <ul className="space-y-2">
              {recent.map((c) => (
                <li key={c.id} className="flex justify-between gap-2 text-sm">
                  <button className="truncate text-left hover:text-accent" onClick={() => openChapter(c.id)}>{c.name}</button>
                  <span className="shrink-0 text-xs text-muted">{fmtShort(c.lastStudied)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card className="p-4">
          <SectionTitle action={<Button size="sm" onClick={() => openRevision({ subjectId: subject.id })}>＋</Button>}>Upcoming revisions</SectionTitle>
          {revs.length === 0 ? <p className="text-[13px] text-muted">None scheduled.</p> : (
            <ul className="space-y-2">
              {revs.map((r) => {
                const b = revisionBucket(r, today);
                return (
                  <li key={r.id} className="flex justify-between gap-2 text-sm">
                    <span className="truncate">{data.chapters.find((c) => c.id === r.chapterId)?.name}</span>
                    <Badge tone={b === "overdue" ? "bad" : "info"}>{b === "overdue" ? "Overdue" : fmtShort(r.date)}</Badge>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      </div>

      <Card className="p-4">
        <SectionTitle action={<Button size="sm" onClick={() => openPractice({ subjectId: subject.id })}>✎ Record test</Button>}>Subject notes</SectionTitle>
        <Field label="Notes for this subject">
          <textarea className="input" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Strategy, formulas to remember, teacher tips…" />
        </Field>
        <div className="mt-2 flex justify-end">
          <Button
            variant="primary"
            size="sm"
            disabled={notes === subject.notes}
            onClick={() => {
              actions.updateSubject(subject.id, { notes });
              toast("Subject notes saved");
            }}
          >
            Save notes
          </Button>
        </div>
      </Card>

      {dlg === "import" && <ImportSyllabusDialog subjectId={subject.id} onClose={() => setDlg(null)} />}
      {dlg === "add" && <AddChapterDialog subjectId={subject.id} onClose={() => setDlg(null)} />}
    </div>
  );
}

function Stat({ l, v }: { l: string; v: string | number }) {
  return (
    <div className="rounded-xl bg-surface2 py-3">
      <dd className="text-xl font-semibold tabular-nums">{v}</dd>
      <dt className="text-xs text-muted">{l}</dt>
    </div>
  );
}
