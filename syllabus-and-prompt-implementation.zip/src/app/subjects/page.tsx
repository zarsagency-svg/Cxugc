"use client";

import { useState } from "react";
import { SubjectCard } from "@/components/Domain";
import { AddChapterDialog, ImportSyllabusDialog } from "@/components/SyllabusTools";
import { Button, Card, PageHeader } from "@/components/ui";
import { useStore } from "@/lib/store";

export default function SubjectsPage() {
  const { data } = useStore();
  const [dlg, setDlg] = useState<"import" | "add" | null>(null);
  const missing = data.subjects.filter((s) => !data.chapters.some((c) => c.subjectId === s.id));
  return (
    <div>
      <PageHeader
        title="My Subjects"
        subtitle="Your six HSLC 2027 subjects."
        actions={
          <>
            <Button onClick={() => setDlg("add")}>＋ Add chapter</Button>
            <Button variant="primary" onClick={() => setDlg("import")}>⇪ Import syllabus</Button>
          </>
        }
      />
      {missing.length > 0 && (
        <Card className="mb-5 border-warn/40 bg-warn-soft p-4 text-sm text-warn">
          <p className="font-medium">Syllabus still needs to be imported for {missing.length} subject{missing.length === 1 ? "" : "s"}:</p>
          <p className="mt-1">{missing.map((m) => m.name).join(", ")}.</p>
          <p className="mt-1 text-[13px] opacity-90">Use “Import syllabus” to paste chapter names from your SEBA syllabus PDF. Nothing is pre-filled so no unofficial chapters are shown.</p>
        </Card>
      )}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {data.subjects.map((s) => (
          <SubjectCard key={s.id} subject={s} />
        ))}
      </div>
      {dlg === "import" && <ImportSyllabusDialog onClose={() => setDlg(null)} />}
      {dlg === "add" && <AddChapterDialog onClose={() => setDlg(null)} />}
    </div>
  );
}
