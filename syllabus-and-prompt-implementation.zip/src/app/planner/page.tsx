"use client";

import { useEffect, useMemo, useState } from "react";
import { useUI } from "@/components/Dialogs";
import { Badge, Button, Card, EmptyState, Field, Modal, PageHeader, PriorityBadge, Select, cx } from "@/components/ui";
import { useStore } from "@/lib/store";
import { TASK_TYPES, type Task } from "@/lib/types";
import { addDays, dateStr, fmtDuration, fmtShort, fmtTime, parseDate, startOfWeek, todayStr, uid } from "@/lib/utils";

type View = "day" | "week" | "upcoming" | "done";

const sortTasks = (a: Task, b: Task) => (a.date + (a.start || "99:99")).localeCompare(b.date + (b.start || "99:99"));

export default function PlannerPage() {
  const { data, actions } = useStore();
  const { openTask, confirm, toast, focus, setFocus } = useUI();
  const today = todayStr();
  const [view, setView] = useState<View>("day");
  const [date, setDate] = useState(today);
  const [planOpen, setPlanOpen] = useState(false);

  useEffect(() => {
    if (focus.date) {
      setDate(focus.date);
      setView("day");
      setFocus({});
    }
  }, [focus.date, setFocus]);

  const subj = (id: string) => data.subjects.find((s) => s.id === id)?.name ?? "";
  const chap = (id: string | null) => data.chapters.find((c) => c.id === id)?.name;

  const dayTasks = (d: string) => data.tasks.filter((t) => t.date === d).sort(sortTasks);
  const totals = (list: Task[]) => ({
    planned: list.reduce((a, t) => a + t.durationMin, 0),
    actual: list.filter((t) => t.done).reduce((a, t) => a + (t.actualMin ?? t.durationMin), 0),
  });

  const weekStart = startOfWeek(date);
  const weekDays = useMemo(() => Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)), [weekStart]);
  const upcoming = data.tasks.filter((t) => !t.done && t.date >= today).sort(sortTasks);
  const overdue = data.tasks.filter((t) => !t.done && t.date < today).sort(sortTasks);
  const completed = data.tasks.filter((t) => t.done).sort((a, b) => sortTasks(b, a));

  const TaskItem = ({ t, showDate }: { t: Task; showDate?: boolean }) => (
    <li className="flex items-start gap-3 rounded-xl border border-line bg-surface p-3">
      <input
        type="checkbox"
        aria-label={`Mark ${t.description || t.type} as completed`}
        className="mt-1 h-5 w-5 shrink-0 accent-[var(--accent)]"
        checked={t.done}
        onChange={(e) => {
          actions.setTaskDone(t.id, e.target.checked);
          toast(e.target.checked ? "Session marked completed" : "Session reopened");
        }}
      />
      <div className="min-w-0 flex-1">
        <button onClick={() => openTask(t)} className={cx("block max-w-full truncate text-left text-sm font-medium hover:text-accent", t.done && "text-muted line-through")}>
          {t.description || t.type}
        </button>
        <p className="mt-0.5 text-xs text-muted">
          {showDate && `${fmtShort(t.date)} · `}
          {t.start && `${fmtTime(t.start)} · `}
          {fmtDuration(t.durationMin)}
          {t.done && t.actualMin != null && ` (actual ${fmtDuration(t.actualMin)})`}
        </p>
        <div className="mt-1.5 flex flex-wrap gap-1.5">
          <Badge tone="accent">{subj(t.subjectId)}</Badge>
          {chap(t.chapterId) && <Badge>{chap(t.chapterId)}</Badge>}
          <Badge tone="neutral">{t.type}</Badge>
          <PriorityBadge value={t.priority} />
          {!t.done && t.date < today && <Badge tone="bad">Past due</Badge>}
        </div>
        {t.notes && <p className="mt-1.5 text-xs text-muted">{t.notes}</p>}
      </div>
      <div className="flex shrink-0 flex-col gap-1 sm:flex-row">
        <Button size="sm" variant="ghost" onClick={() => openTask(t)} aria-label="Edit session">
          ✐
        </Button>
        {!t.done && (
          <Button
            size="sm"
            variant="ghost"
            aria-label="Move to tomorrow"
            title="Move to tomorrow"
            onClick={() => {
              actions.saveTask({ ...t, date: addDays(t.date < today ? today : t.date, 1) });
              toast("Rescheduled to tomorrow");
            }}
          >
            →
          </Button>
        )}
        <Button
          size="sm"
          variant="ghost"
          aria-label="Delete session"
          onClick={() =>
            confirm({
              title: "Delete this study session?",
              text: "This removes the session from your planner and statistics.",
              confirmLabel: "Delete",
              onYes: () => {
                actions.deleteTask(t.id);
                toast("Session deleted");
              },
            })
          }
        >
          🗑
        </Button>
      </div>
    </li>
  );

  const dt = dayTasks(date);
  const dtot = totals(dt);
  const target = data.settings.dailyTargetMin;

  return (
    <div>
      <PageHeader
        title="Daily Planner"
        subtitle="Sessions are only completed when you tick them — never automatically."
        actions={
          <>
            <Button onClick={() => setPlanOpen(true)}>✦ Plan my day</Button>
            <Button variant="primary" onClick={() => openTask({ date })}>＋ Add session</Button>
          </>
        }
      />

      <div className="mb-4 flex gap-1 overflow-x-auto rounded-xl bg-surface2 p-1" role="tablist" aria-label="Planner views">
        {(
          [
            ["day", "Day"],
            ["week", "Week"],
            ["upcoming", `Upcoming (${upcoming.length})`],
            ["done", `Completed (${completed.length})`],
          ] as [View, string][]
        ).map(([v, l]) => (
          <button
            key={v}
            role="tab"
            aria-selected={view === v}
            onClick={() => setView(v)}
            className={cx("min-h-10 flex-1 whitespace-nowrap rounded-lg px-3 text-sm font-medium transition", view === v ? "bg-surface shadow-sm" : "text-muted hover:text-fg")}
          >
            {l}
          </button>
        ))}
      </div>

      {(view === "day" || view === "week") && (
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <Button size="sm" onClick={() => setDate(addDays(date, view === "day" ? -1 : -7))} aria-label="Previous">
            ‹
          </Button>
          <input type="date" aria-label="Pick date" className="input !w-auto" value={date} onChange={(e) => e.target.value && setDate(e.target.value)} />
          <Button size="sm" onClick={() => setDate(addDays(date, view === "day" ? 1 : 7))} aria-label="Next">
            ›
          </Button>
          <Button size="sm" onClick={() => setDate(today)}>
            Today
          </Button>
        </div>
      )}

      {view === "day" && (
        <div className="space-y-3">
          <Card className="flex flex-wrap items-center gap-x-6 gap-y-2 p-4">
            <div>
              <p className="text-xs text-muted">{parseDate(date).toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long" })}</p>
              <p className="text-lg font-semibold">{date === today ? "Today" : fmtShort(date)}</p>
            </div>
            <div>
              <p className="text-xs text-muted">Planned</p>
              <p className="font-semibold">{fmtDuration(dtot.planned)}</p>
            </div>
            <div>
              <p className="text-xs text-muted">Completed time</p>
              <p className="font-semibold">{fmtDuration(dtot.actual)}</p>
            </div>
            <div>
              <p className="text-xs text-muted">Personal goal</p>
              <p className="font-semibold">{target ? fmtDuration(target) : "Not set"}</p>
            </div>
          </Card>
          {dt.length === 0 ? (
            <EmptyState title="No sessions on this day" text="Add one session, or let Plan My Day set up several chapters at once." action={<Button variant="primary" onClick={() => openTask({ date })}>Add session</Button>} />
          ) : (
            <ul className="space-y-2">{dt.map((t) => <TaskItem key={t.id} t={t} />)}</ul>
          )}
        </div>
      )}

      {view === "week" && (
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3">
          {weekDays.map((d) => {
            const list = dayTasks(d);
            const tt = totals(list);
            return (
              <Card key={d} className={cx("p-3", d === today && "ring-2 ring-accent")}>
                <div className="mb-2 flex items-center justify-between">
                  <button className="text-left" onClick={() => { setDate(d); setView("day"); }}>
                    <p className="text-sm font-semibold">{fmtShort(d)}</p>
                    <p className="text-xs text-muted">
                      Planned {fmtDuration(tt.planned)} · done {fmtDuration(tt.actual)}
                    </p>
                  </button>
                  <Button size="sm" variant="ghost" aria-label={`Add session on ${d}`} onClick={() => openTask({ date: d })}>
                    ＋
                  </Button>
                </div>
                {list.length === 0 ? <p className="text-xs text-muted">Free day</p> : (
                  <ul className="space-y-1.5">
                    {list.map((t) => (
                      <li key={t.id}>
                        <button onClick={() => openTask(t)} className="flex w-full items-center gap-2 rounded-lg bg-surface2 px-2.5 py-2 text-left text-[13px]">
                          <span className={t.done ? "text-ok" : "text-muted"}>{t.done ? "✓" : "○"}</span>
                          <span className={cx("min-w-0 flex-1 truncate", t.done && "line-through text-muted")}>{subj(t.subjectId)} · {t.description || t.type}</span>
                          <span className="shrink-0 text-xs text-muted">{fmtDuration(t.durationMin)}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {view === "upcoming" && (
        <div className="space-y-4">
          {overdue.length > 0 && (
            <div>
              <h2 className="mb-2 text-sm font-semibold text-bad">Past due, not completed ({overdue.length})</h2>
              <ul className="space-y-2">{overdue.map((t) => <TaskItem key={t.id} t={t} showDate />)}</ul>
            </div>
          )}
          {upcoming.length === 0 ? <EmptyState title="No upcoming sessions" action={<Button variant="primary" onClick={() => openTask({})}>Add session</Button>} /> : (
            <ul className="space-y-2">{upcoming.map((t) => <TaskItem key={t.id} t={t} showDate />)}</ul>
          )}
        </div>
      )}

      {view === "done" &&
        (completed.length === 0 ? <EmptyState title="No completed sessions yet" text="Tick a session when you have actually finished it." /> : (
          <ul className="space-y-2">{completed.map((t) => <TaskItem key={t.id} t={t} showDate />)}</ul>
        ))}

      {planOpen && <PlanDay date={date} onClose={() => setPlanOpen(false)} />}
    </div>
  );
}

function PlanDay({ date: initial, onClose }: { date: string; onClose: () => void }) {
  const { data, actions } = useStore();
  const { toast } = useUI();
  const [date, setDate] = useState(initial);
  const [start, setStart] = useState("16:00");
  const [dur, setDur] = useState("45");
  const [type, setType] = useState<string>(TASK_TYPES[0]);
  const [sid, setSid] = useState("");
  const [sel, setSel] = useState<string[]>([]);
  const chapters = data.chapters.filter((c) => (!sid || c.subjectId === sid) && c.status !== "completed");

  const create = () => {
    const d = Number(dur);
    if (!sel.length) return toast("Select at least one chapter", "error");
    if (!Number.isFinite(d) || d <= 0) return toast("Enter a valid duration", "error");
    let cursor = start ? Number(start.slice(0, 2)) * 60 + Number(start.slice(3, 5)) : null;
    sel.forEach((id) => {
      const ch = data.chapters.find((c) => c.id === id)!;
      const time = cursor == null ? "" : `${String(Math.floor(cursor / 60) % 24).padStart(2, "0")}:${String(cursor % 60).padStart(2, "0")}`;
      actions.saveTask({
        id: uid("task"),
        date,
        start: time,
        durationMin: d,
        subjectId: ch.subjectId,
        chapterId: ch.id,
        type,
        description: `${type}: ${ch.name}`,
        priority: ch.priority,
        done: false,
        actualMin: null,
        notes: "",
      });
      if (cursor != null) cursor += d + 10;
    });
    toast(`${sel.length} session${sel.length === 1 ? "" : "s"} planned for ${fmtShort(date)}`);
    onClose();
  };

  return (
    <Modal
      open
      onClose={onClose}
      title="Plan my day"
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={create}>
            Create {sel.length || ""} session{sel.length === 1 ? "" : "s"}
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Date">
            <input type="date" className="input" value={dateStr(parseDate(date))} onChange={(e) => e.target.value && setDate(e.target.value)} />
          </Field>
          <Field label="First start (optional)">
            <input type="time" className="input" value={start} onChange={(e) => setStart(e.target.value)} />
          </Field>
          <Field label="Minutes per session">
            <input type="number" min={5} className="input" value={dur} onChange={(e) => setDur(e.target.value)} />
          </Field>
          <Field label="Task type">
            <Select value={type} onChange={setType} options={TASK_TYPES.map((t) => ({ value: t, label: t }))} />
          </Field>
        </div>
        <Field label="Show chapters from">
          <Select value={sid} onChange={setSid} options={[{ value: "", label: "All subjects" }, ...data.subjects.map((s) => ({ value: s.id, label: s.name }))]} />
        </Field>
        <p className="text-xs text-muted">Select chapters from one or several subjects. With a start time, sessions are lined up with 10-minute breaks.</p>
        {chapters.length === 0 ? (
          <EmptyState title="No unfinished chapters available" text="Import your syllabus first, or add sessions manually." />
        ) : (
          <ul className="max-h-64 space-y-1 overflow-y-auto rounded-xl border border-line p-1.5">
            {chapters.map((c) => (
              <li key={c.id}>
                <label className="flex min-h-11 cursor-pointer items-center gap-3 rounded-lg px-2 hover:bg-surface2">
                  <input
                    type="checkbox"
                    className="h-4 w-4 accent-[var(--accent)]"
                    checked={sel.includes(c.id)}
                    onChange={(e) => setSel(e.target.checked ? [...sel, c.id] : sel.filter((x) => x !== c.id))}
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm">{c.name}</span>
                    <span className="block truncate text-xs text-muted">{data.subjects.find((s) => s.id === c.subjectId)?.name}</span>
                  </span>
                </label>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Modal>
  );
}
