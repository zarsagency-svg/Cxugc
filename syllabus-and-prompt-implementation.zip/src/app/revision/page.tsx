"use client";

import { useState } from "react";
import { useUI } from "@/components/Dialogs";
import { Badge, Button, Card, EmptyState, Field, Modal, PageHeader, Select, cx } from "@/components/ui";
import { useStore } from "@/lib/store";
import type { Revision } from "@/lib/types";
import { diffDays, fmtDate, fmtShort, pct, revisionBucket, todayStr } from "@/lib/utils";

export default function RevisionPage() {
  const { data, actions } = useStore();
  const { openRevision, confirm, toast, openChapter } = useUI();
  const [completing, setCompleting] = useState<Revision | null>(null);
  const today = todayStr();

  const sorted = [...data.revisions].sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  const groups = {
    overdue: sorted.filter((r) => revisionBucket(r, today) === "overdue"),
    today: sorted.filter((r) => revisionBucket(r, today) === "today"),
    upcoming: sorted.filter((r) => revisionBucket(r, today) === "upcoming"),
    done: sorted.filter((r) => r.done).reverse(),
  };
  const rate = pct(groups.done.length, data.revisions.length);

  const Item = ({ r }: { r: Revision }) => {
    const ch = data.chapters.find((c) => c.id === r.chapterId);
    const sub = data.subjects.find((s) => s.id === r.subjectId);
    const b = revisionBucket(r, today);
    const late = b === "overdue" ? diffDays(today, r.date) : 0;
    return (
      <li className={cx("rounded-xl border bg-surface p-3", b === "overdue" ? "border-bad/50 bg-bad-soft/40" : "border-line")}>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="min-w-0 flex-1">
            <button onClick={() => ch && openChapter(ch.id)} className="block max-w-full truncate text-left text-sm font-medium hover:text-accent">
              {ch?.name ?? "Deleted chapter"}
            </button>
            <p className="mt-0.5 text-xs text-muted">
              {sub?.name} · {r.type} · {fmtShort(r.date)}
            </p>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {b === "overdue" && <Badge tone="bad">⚠ Overdue by {late} day{late === 1 ? "" : "s"}</Badge>}
              {b === "today" && <Badge tone="warn">Due today</Badge>}
              {b === "upcoming" && <Badge tone="info">In {diffDays(r.date, today)} day{diffDays(r.date, today) === 1 ? "" : "s"}</Badge>}
              {r.done && <Badge tone="ok">✓ Done {r.completedOn ? fmtDate(r.completedOn) : ""}</Badge>}
              {r.difficulty != null && <Badge>Difficulty {r.difficulty}/5</Badge>}
            </div>
            {r.notes && <p className="mt-1.5 text-xs text-muted">{r.notes}</p>}
          </div>
          <div className="flex flex-wrap gap-1.5">
            {!r.done ? (
              <Button size="sm" variant="primary" onClick={() => setCompleting(r)}>
                ✓ Complete
              </Button>
            ) : (
              <Button size="sm" onClick={() => { actions.reopenRevision(r.id); toast("Revision reopened"); }}>
                Reopen
              </Button>
            )}
            <Button size="sm" onClick={() => openRevision({ subjectId: r.subjectId, chapterId: r.chapterId })}>
              ＋ Another
            </Button>
            <Button size="sm" variant="ghost" aria-label="Edit revision" onClick={() => openRevision(r)}>
              ✐
            </Button>
            <Button
              size="sm"
              variant="ghost"
              aria-label="Delete revision"
              onClick={() =>
                confirm({
                  title: "Delete this revision entry?",
                  text: "Completed revision records are normally kept for your history. Delete only if it was created by mistake.",
                  confirmLabel: "Delete",
                  onYes: () => {
                    actions.deleteRevision(r.id);
                    toast("Revision deleted");
                  },
                })
              }
            >
              🗑
            </Button>
          </div>
        </div>
      </li>
    );
  };

  const Section = ({ title, list, tone }: { title: string; list: Revision[]; tone?: string }) =>
    list.length === 0 ? null : (
      <section>
        <h2 className={cx("mb-2 text-sm font-semibold", tone)}>
          {title} ({list.length})
        </h2>
        <ul className="space-y-2">{list.map((r) => <Item key={r.id} r={r} />)}</ul>
      </section>
    );

  return (
    <div>
      <PageHeader
        title="Revision Planner"
        subtitle="Choose your own revision dates and types — nothing is scheduled automatically."
        actions={<Button variant="primary" onClick={() => openRevision({})}>＋ Schedule revision</Button>}
      />
      <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          ["Due today", groups.today.length],
          ["Overdue", groups.overdue.length],
          ["Upcoming", groups.upcoming.length],
          ["Completion rate", data.revisions.length ? `${rate}%` : "—"],
        ].map(([l, v]) => (
          <Card key={l} className="p-4">
            <p className="text-xs text-muted">{l}</p>
            <p className={cx("text-2xl font-semibold tabular-nums", l === "Overdue" && Number(v) > 0 && "text-bad")}>{v}</p>
          </Card>
        ))}
      </div>
      {data.revisions.length === 0 ? (
        <EmptyState
          title="No revisions scheduled"
          text="Schedule a first, second or final revision for any chapter. You can also schedule from a chapter’s details."
          action={<Button variant="primary" onClick={() => openRevision({})}>Schedule your first revision</Button>}
        />
      ) : (
        <div className="space-y-6">
          <Section title="Overdue" list={groups.overdue} tone="text-bad" />
          <Section title="Due today" list={groups.today} tone="text-warn" />
          <Section title="Upcoming" list={groups.upcoming} />
          <Section title="Completed" list={groups.done} tone="text-ok" />
        </div>
      )}
      {completing && (
        <CompleteDialog
          r={completing}
          onClose={() => setCompleting(null)}
          onDone={(d, n) => {
            actions.completeRevision(completing.id, d, n);
            toast("Revision completed — nicely done");
            setCompleting(null);
          }}
        />
      )}
    </div>
  );
}

function CompleteDialog({ r, onClose, onDone }: { r: Revision; onClose: () => void; onDone: (d: number | null, n: string) => void }) {
  const [d, setD] = useState(r.difficulty != null ? String(r.difficulty) : "");
  const [n, setN] = useState(r.notes);
  return (
    <Modal
      open
      onClose={onClose}
      title="Complete revision"
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={() => onDone(d ? Number(d) : null, n)}>
            Mark completed
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <Field label="How difficult was it? (optional)">
          <Select
            value={d}
            onChange={setD}
            options={[
              { value: "", label: "Not rated" },
              { value: "1", label: "1 – Very easy" },
              { value: "2", label: "2 – Easy" },
              { value: "3", label: "3 – Medium" },
              { value: "4", label: "4 – Hard" },
              { value: "5", label: "5 – Very hard" },
            ]}
          />
        </Field>
        <Field label="Notes">
          <textarea className="input" value={n} onChange={(e) => setN(e.target.value)} />
        </Field>
      </div>
    </Modal>
  );
}
