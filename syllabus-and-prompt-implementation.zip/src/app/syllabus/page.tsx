"use client";

import { useMemo, useState } from "react";
import { ChapterRow } from "@/components/Domain";
import { AddChapterDialog, ImportSyllabusDialog } from "@/components/SyllabusTools";
import { Button, Card, EmptyState, PageHeader, Select } from "@/components/ui";
import { useStore } from "@/lib/store";
import { PRIORITIES, STATUSES, UNDERSTANDINGS } from "@/lib/types";
import { addDays, nextRevisionOf, priorityRank, statusLabel, todayStr, understandingRank, weakReasons } from "@/lib/utils";

const SORTS = [
  { value: "order", label: "Syllabus order" },
  { value: "name", label: "Name (A–Z)" },
  { value: "status", label: "Status" },
  { value: "priority", label: "Priority (high first)" },
  { value: "understanding", label: "Understanding (weakest first)" },
  { value: "studied", label: "Last studied (recent first)" },
  { value: "revision", label: "Next revision (soonest first)" },
];

export default function SyllabusPage() {
  const { data } = useStore();
  const [q, setQ] = useState("");
  const [subject, setSubject] = useState("");
  const [status, setStatus] = useState("");
  const [und, setUnd] = useState("");
  const [prio, setPrio] = useState("");
  const [rev, setRev] = useState("");
  const [weakOnly, setWeakOnly] = useState(false);
  const [sort, setSort] = useState("order");
  const [dlg, setDlg] = useState<"import" | "add" | null>(null);
  const today = todayStr();

  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    const subjOrder = (id: string) => data.subjects.findIndex((x) => x.id === id);
    let out = data.chapters.filter((c) => {
      if (subject && c.subjectId !== subject) return false;
      if (status && c.status !== status) return false;
      if (und && c.understanding !== und) return false;
      if (prio && c.priority !== prio) return false;
      if (weakOnly && weakReasons(c, data.practice).length === 0) return false;
      if (rev) {
        const nr = nextRevisionOf(c, data.revisions);
        if (rev === "overdue" && !(nr && nr < today)) return false;
        if (rev === "week" && !(nr && nr >= today && nr <= addDays(today, 7))) return false;
        if (rev === "scheduled" && !nr) return false;
        if (rev === "none" && nr) return false;
      }
      if (s && !(c.name.toLowerCase().includes(s) || c.unit.toLowerCase().includes(s) || c.subtopics.some((t) => t.toLowerCase().includes(s)))) return false;
      return true;
    });
    const cmp: Record<string, (a: (typeof out)[number], b: (typeof out)[number]) => number> = {
      order: (a, b) => subjOrder(a.subjectId) - subjOrder(b.subjectId) || a.order - b.order,
      name: (a, b) => a.name.localeCompare(b.name),
      status: (a, b) => STATUSES.findIndex((x) => x.value === a.status) - STATUSES.findIndex((x) => x.value === b.status),
      priority: (a, b) => priorityRank(b.priority) - priorityRank(a.priority),
      understanding: (a, b) => (understandingRank(a.understanding) || 9) - (understandingRank(b.understanding) || 9),
      studied: (a, b) => (b.lastStudied ?? "").localeCompare(a.lastStudied ?? ""),
      revision: (a, b) => (nextRevisionOf(a, data.revisions) ?? "9999").localeCompare(nextRevisionOf(b, data.revisions) ?? "9999"),
    };
    out = [...out].sort(cmp[sort]);
    return out;
  }, [data, q, subject, status, und, prio, rev, weakOnly, sort, today]);

  const filtersOn = !!(q || subject || status || und || prio || rev || weakOnly);
  const reset = () => {
    setQ("");
    setSubject("");
    setStatus("");
    setUnd("");
    setPrio("");
    setRev("");
    setWeakOnly(false);
  };

  return (
    <div>
      <PageHeader
        title="Syllabus Tracker"
        subtitle={`${data.chapters.length} chapters across ${data.subjects.length} subjects. Change status and understanding right from the list.`}
        actions={
          <>
            <Button onClick={() => setDlg("add")}>＋ Add chapter</Button>
            <Button variant="primary" onClick={() => setDlg("import")}>⇪ Import syllabus</Button>
          </>
        }
      />

      <Card className="mb-4 space-y-3 p-3 sm:p-4">
        <input type="search" aria-label="Search chapters" className="input" placeholder="Search chapters, units, subtopics…" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-6">
          <Select aria-label="Filter by subject" value={subject} onChange={setSubject} options={[{ value: "", label: "All subjects" }, ...data.subjects.map((s) => ({ value: s.id, label: s.name }))]} />
          <Select aria-label="Filter by status" value={status} onChange={setStatus} options={[{ value: "", label: "Any status" }, ...STATUSES.map((s) => ({ value: s.value, label: s.label }))]} />
          <Select aria-label="Filter by understanding" value={und} onChange={setUnd} options={[{ value: "", label: "Any understanding" }, ...UNDERSTANDINGS.map((s) => ({ value: s.value, label: s.label }))]} />
          <Select aria-label="Filter by priority" value={prio} onChange={setPrio} options={[{ value: "", label: "Any priority" }, ...PRIORITIES.map((s) => ({ value: s.value, label: s.label }))]} />
          <Select
            aria-label="Filter by revision due date"
            value={rev}
            onChange={setRev}
            options={[
              { value: "", label: "Any revision date" },
              { value: "overdue", label: "Revision overdue" },
              { value: "week", label: "Due in 7 days" },
              { value: "scheduled", label: "Has revision date" },
              { value: "none", label: "No revision date" },
            ]}
          />
          <Select aria-label="Sort chapters" value={sort} onChange={setSort} options={SORTS} />
        </div>
        <div className="flex flex-wrap items-center justify-between gap-2">
          <label className="flex min-h-10 items-center gap-2 text-sm font-medium">
            <input type="checkbox" className="h-4 w-4 accent-[var(--accent)]" checked={weakOnly} onChange={(e) => setWeakOnly(e.target.checked)} />
            Show only weak chapters
          </label>
          <div className="flex items-center gap-3 text-[13px] text-muted">
            <span>
              {list.length} shown{status ? ` · ${statusLabel(status as never)}` : ""}
            </span>
            {filtersOn && (
              <Button size="sm" variant="ghost" onClick={reset}>
                Clear filters
              </Button>
            )}
          </div>
        </div>
      </Card>

      {data.chapters.length === 0 ? (
        <EmptyState
          title="No chapters yet"
          text="Your syllabus PDF could not be read automatically, so nothing was invented. Paste each subject’s chapter list using “Import syllabus”, or add chapters manually."
          action={<Button variant="primary" onClick={() => setDlg("import")}>Import syllabus</Button>}
        />
      ) : list.length === 0 ? (
        <EmptyState title="No chapters match these filters" action={<Button onClick={reset}>Clear filters</Button>} />
      ) : (
        <div className="space-y-2">
          {list.map((c) => (
            <ChapterRow key={c.id} chapter={c} showSubject expandable />
          ))}
        </div>
      )}
      {dlg === "import" && <ImportSyllabusDialog onClose={() => setDlg(null)} />}
      {dlg === "add" && <AddChapterDialog onClose={() => setDlg(null)} />}
    </div>
  );
}
