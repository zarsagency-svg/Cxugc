"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo } from "react";
import { useUI } from "@/components/Dialogs";
import { SubjectCard } from "@/components/Domain";
import { Badge, Button, Card, EmptyState, ProgressBar, Ring, SectionTitle, StatusBadge } from "@/components/ui";
import { useStore } from "@/lib/store";
import { diffDays, fmtDate, fmtDuration, fmtShort, fmtTime, overallStats, revisionBucket, todayStr } from "@/lib/utils";

export default function DashboardPage() {
  const { data, actions } = useStore();
  const { openTask, openRevision, openPractice, openChapter, toast } = useUI();
  const router = useRouter();
  const today = todayStr();
  const st = overallStats(data.chapters);

  const examDate = data.settings.examDate;
  const target = examDate ?? "2027-02-01";
  const days = diffDays(target, today);

  const stats = useMemo(() => {
    const upcomingRev = data.revisions.filter((r) => !r.done && r.date >= today).length;
    const overdue = data.revisions.filter((r) => !r.done && r.date < today).length;
    const sessions = data.tasks.filter((t) => t.done).length + data.timerLogs.length;
    const todays = data.tasks.filter((t) => t.date === today).sort((a, b) => (a.start || "99").localeCompare(b.start || "99"));
    const next = data.tasks
      .filter((t) => !t.done && (t.date > today || (t.date === today && true)))
      .sort((a, b) => (a.date + (a.start || "99")).localeCompare(b.date + (b.start || "99")))[0];
    const recent = [...data.chapters].filter((c) => c.lastStudied).sort((a, b) => (b.lastStudied! > a.lastStudied! ? 1 : -1)).slice(0, 4);
    const inProg = data.chapters.filter((c) => c.status === "in_progress").slice(0, 4);
    const revs = data.revisions
      .filter((r) => !r.done)
      .sort((a, b) => (a.date < b.date ? -1 : 1))
      .slice(0, 4);
    return { upcomingRev, overdue, sessions, todays, next, recent, inProg, revs };
  }, [data, today]);

  const cards = [
    { label: "Syllabus completion", value: `${st.percent}%`, hint: st.total ? `${st.completed} of ${st.total} chapters` : "Add chapters to begin" },
    { label: "Total chapters", value: st.total },
    { label: "Completed", value: st.completed },
    { label: "In progress", value: st.inProgress },
    { label: "Not started", value: st.notStarted },
    { label: "Needs revision", value: st.needsRevision },
    { label: "Study sessions done", value: stats.sessions, hint: "Planner + timer" },
    { label: "Upcoming revisions", value: stats.upcomingRev, hint: stats.overdue ? `${stats.overdue} overdue` : undefined },
  ];

  const nextTaskSubject = stats.next ? data.subjects.find((s) => s.id === stats.next!.subjectId)?.name : "";

  return (
    <div className="space-y-6">
      <section className="overflow-hidden rounded-3xl border border-line bg-surface p-5 shadow-card sm:p-7">
        <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
          <div className="min-w-0">
            <Badge tone="accent">Class 10 HSLC 2027</Badge>
            <h1 className="mt-3 text-2xl font-semibold tracking-tight sm:text-3xl">Your Personal Exam Preparation Dashboard</h1>
            <p className="mt-2 max-w-xl text-sm text-muted">
              {st.total === 0
                ? "Start by adding your syllabus chapters in the Syllabus Tracker — paste them from your SEBA syllabus PDF or add them one by one."
                : `You have completed ${st.completed} of ${st.total} chapters. Keep going — one chapter at a time.`}
            </p>
          </div>
          <div className="flex items-center gap-5 rounded-2xl bg-surface2 p-4">
            <Ring value={st.percent} size={92}>
              <span className="text-xl font-semibold tabular-nums">{st.percent}%</span>
            </Ring>
            <div>
              <p className="text-xs font-medium uppercase tracking-wide text-muted">{examDate ? "Exam countdown" : "Countdown to Feb 2027"}</p>
              <p className="text-3xl font-semibold tabular-nums">{days >= 0 ? days : 0}</p>
              <p className="text-xs text-muted">
                {days >= 0 ? "days to go" : "target date has passed"}
              </p>
              <p className="mt-1 max-w-[190px] text-[11px] leading-snug text-muted">
                {examDate ? `Target: ${fmtDate(examDate)}` : "HSLC window: Feb–Mar 2027. Exact date not set — add it in Settings once announced."}
              </p>
            </div>
          </div>
        </div>
      </section>

      <section aria-label="Quick actions" className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
        <Button variant="primary" onClick={() => router.push("/syllabus")}>☑ Update Chapter Progress</Button>
        <Button onClick={() => openTask({})}>＋ Add Study Session</Button>
        <Button onClick={() => openRevision({})}>↻ Schedule Revision</Button>
        <Button onClick={() => openPractice({})}>✎ Record Practice Test</Button>
        <Button onClick={() => router.push("/weak")} className="col-span-2 sm:col-span-1">⚑ Open Weak Chapters</Button>
      </section>

      <section aria-label="Summary">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {cards.map((c, i) => (
            <Card key={c.label} className={`p-4 ${i === 0 ? "col-span-2 sm:col-span-1" : ""}`}>
              <p className="text-xs font-medium text-muted">{c.label}</p>
              <p className="mt-1 text-2xl font-semibold tabular-nums">{c.value}</p>
              {i === 0 && <ProgressBar className="mt-2" value={st.percent} label="Overall completion" />}
              {c.hint && <p className="mt-1 text-xs text-muted">{c.hint}</p>}
            </Card>
          ))}
        </div>
        {st.total === 0 && (
          <p className="mt-3 text-[13px] text-muted">All numbers are calculated from your saved data — they start at zero until you add and update chapters.</p>
        )}
      </section>

      <section>
        <SectionTitle action={<Link href="/subjects" className="text-[13px] font-medium text-accent">View all</Link>}>Subject progress</SectionTitle>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {data.subjects.map((s) => (
            <SubjectCard key={s.id} subject={s} />
          ))}
        </div>
      </section>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="p-4">
          <SectionTitle
            action={
              <Button size="sm" onClick={() => openTask({ date: today })}>
                ＋ Add
              </Button>
            }
          >
            Today’s plan
          </SectionTitle>
          {stats.todays.length === 0 ? (
            <EmptyState title="Nothing scheduled for today" text="Plan a study session to keep your day organised." action={<Button variant="primary" onClick={() => openTask({ date: today })}>Create a study session</Button>} />
          ) : (
            <ul className="space-y-2">
              {stats.todays.map((t) => (
                <li key={t.id} className="flex items-center gap-3 rounded-xl bg-surface2 p-3">
                  <input
                    type="checkbox"
                    aria-label={`Mark ${t.description || t.type} as completed`}
                    className="h-5 w-5 accent-[var(--accent)]"
                    checked={t.done}
                    onChange={(e) => {
                      actions.setTaskDone(t.id, e.target.checked);
                      toast(e.target.checked ? "Session completed" : "Session reopened");
                    }}
                  />
                  <button className="min-w-0 flex-1 text-left" onClick={() => openTask(t)}>
                    <span className={`block truncate text-sm font-medium ${t.done ? "text-muted line-through" : ""}`}>{t.description || t.type}</span>
                    <span className="block truncate text-xs text-muted">
                      {data.subjects.find((s) => s.id === t.subjectId)?.name} · {t.start ? fmtTime(t.start) + " · " : ""}
                      {fmtDuration(t.durationMin)}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="p-4">
          <SectionTitle>Continue studying</SectionTitle>
          <div className="space-y-4">
            <div>
              <p className="mb-1.5 text-xs font-medium uppercase tracking-wide text-muted">Next scheduled task</p>
              {stats.next ? (
                <button onClick={() => openTask(stats.next!)} className="w-full rounded-xl bg-accent-soft p-3 text-left">
                  <span className="block text-sm font-medium">{stats.next.description || stats.next.type}</span>
                  <span className="text-xs text-muted">
                    {fmtShort(stats.next.date)} {stats.next.start && `· ${fmtTime(stats.next.start)}`} · {nextTaskSubject}
                  </span>
                </button>
              ) : (
                <p className="text-[13px] text-muted">No upcoming study task. Schedule one from the planner.</p>
              )}
            </div>
            <MiniList title="In progress" empty="No chapters in progress.">
              {stats.inProg.map((c) => (
                <li key={c.id}>
                  <button className="flex w-full items-center justify-between gap-2 py-1.5 text-left text-sm hover:text-accent" onClick={() => openChapter(c.id)}>
                    <span className="truncate">{c.name}</span>
                    <StatusBadge status={c.status} />
                  </button>
                </li>
              ))}
            </MiniList>
            <MiniList title="Recently studied" empty="Nothing studied yet.">
              {stats.recent.map((c) => (
                <li key={c.id}>
                  <button className="flex w-full items-center justify-between gap-2 py-1.5 text-left text-sm hover:text-accent" onClick={() => openChapter(c.id)}>
                    <span className="truncate">{c.name}</span>
                    <span className="shrink-0 text-xs text-muted">{fmtShort(c.lastStudied)}</span>
                  </button>
                </li>
              ))}
            </MiniList>
            <MiniList title="Upcoming revisions" empty="No revisions scheduled.">
              {stats.revs.map((r) => {
                const ch = data.chapters.find((c) => c.id === r.chapterId);
                const b = revisionBucket(r, today);
                return (
                  <li key={r.id}>
                    <Link href="/revision" className="flex items-center justify-between gap-2 py-1.5 text-sm hover:text-accent">
                      <span className="truncate">{ch?.name ?? "Chapter"}</span>
                      <Badge tone={b === "overdue" ? "bad" : b === "today" ? "warn" : "info"}>{b === "overdue" ? "Overdue" : fmtShort(r.date)}</Badge>
                    </Link>
                  </li>
                );
              })}
            </MiniList>
          </div>
        </Card>
      </div>
    </div>
  );
}

function MiniList({ title, empty, children }: { title: string; empty: string; children: React.ReactNode[] }) {
  return (
    <div>
      <p className="mb-1 text-xs font-medium uppercase tracking-wide text-muted">{title}</p>
      {children.length === 0 ? <p className="text-[13px] text-muted">{empty}</p> : <ul className="divide-y divide-line">{children}</ul>}
    </div>
  );
}
