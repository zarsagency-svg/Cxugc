"use client";

import { useMemo } from "react";
import { BarList, Card, ColumnChart, Donut, EmptyState, LineChart, PageHeader, ProgressBar, Ring, SectionTitle } from "@/components/ui";
import { useStore } from "@/lib/store";
import { addDays, fmtDate, fmtDuration, isoToLocalDate, overallStats, pct, practicePct, startOfWeek, subjectStats, todayStr, weakReasons } from "@/lib/utils";

export default function AnalyticsPage() {
  const { data } = useStore();
  const today = todayStr();
  const st = overallStats(data.chapters);

  const a = useMemo(() => {
    // minutes studied per local date: completed planner sessions + saved timer sessions
    const perDay = new Map<string, number>();
    const perSubject = new Map<string, number>();
    const add = (d: string, s: string, m: number) => {
      perDay.set(d, (perDay.get(d) ?? 0) + m);
      perSubject.set(s, (perSubject.get(s) ?? 0) + m);
    };
    data.tasks.filter((t) => t.done).forEach((t) => add(t.date, t.subjectId, t.actualMin ?? t.durationMin));
    data.timerLogs.forEach((l) => add(isoToLocalDate(l.startedAt), l.subjectId, l.durationSec / 60));
    const days = Array.from({ length: 14 }, (_, i) => addDays(today, i - 13));
    const daily = days.map((d) => ({ label: fmtDate(d, { day: "numeric" }), value: Math.round(perDay.get(d) ?? 0), highlight: d === today }));
    const wk0 = startOfWeek(today);
    const weeks = Array.from({ length: 8 }, (_, i) => addDays(wk0, (i - 7) * 7));
    const weekly = weeks.map((w, idx) => {
      let sum = 0;
      for (let k = 0; k < 7; k++) sum += perDay.get(addDays(w, k)) ?? 0;
      return { label: fmtDate(w, { day: "numeric", month: "short" }), value: Math.round(sum), highlight: idx === 7 };
    });
    const totalMin = [...perDay.values()].reduce((x, y) => x + y, 0);
    const scored = [...data.practice].filter((p) => practicePct(p) != null).sort((x, y) => (x.date < y.date ? -1 : x.date > y.date ? 1 : 0));
    const weak = data.chapters.filter((c) => weakReasons(c, data.practice).length > 0).length;
    const revDone = data.revisions.filter((r) => r.done).length;
    return { daily, weekly, perSubject, totalMin, scored, weak, revDone };
  }, [data, today]);

  const subjectRows = data.subjects.map((s) => ({ s, st: subjectStats(s.id, data.chapters) }));
  const withChapters = subjectRows.filter((r) => r.st.total > 0);
  const studyRows = data.subjects.map((s) => ({ label: s.name, value: Math.round(a.perSubject.get(s.id) ?? 0), sub: fmtDuration(a.perSubject.get(s.id) ?? 0) })).filter((r) => r.value > 0);
  const hasActivity = a.totalMin > 0;

  return (
    <div className="space-y-5">
      <PageHeader title="Progress Analytics" subtitle="Every number here is calculated from what you have recorded — nothing is estimated or pre-filled." />

      <div className="grid gap-5 md:grid-cols-3">
        <Card className="flex items-center gap-5 p-5">
          <Ring value={st.percent} size={104}>
            <span className="text-2xl font-semibold tabular-nums">{st.percent}%</span>
          </Ring>
          <div>
            <p className="text-sm font-semibold">Overall syllabus</p>
            <p className="text-[13px] text-muted">{st.total ? `${st.completed} of ${st.total} chapters completed` : "No chapters added yet"}</p>
            <p className="mt-1 text-xs text-muted">Each chapter counts equally. Subjects with no chapters are excluded.</p>
          </div>
        </Card>
        <Card className="p-5">
          <p className="text-sm font-semibold">Weak chapters</p>
          <p className="mt-1 text-4xl font-semibold tabular-nums">{a.weak}</p>
          <p className="text-[13px] text-muted">{st.total ? `${pct(a.weak, st.total)}% of your chapters` : "Add chapters to detect weak areas"}</p>
        </Card>
        <Card className="p-5">
          <p className="text-sm font-semibold">Revision completion rate</p>
          <p className="mt-1 text-4xl font-semibold tabular-nums">{data.revisions.length ? `${pct(a.revDone, data.revisions.length)}%` : "—"}</p>
          <p className="text-[13px] text-muted">{data.revisions.length ? `${a.revDone} of ${data.revisions.length} scheduled revisions done` : "Schedule revisions to track this"}</p>
        </Card>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="p-5">
          <SectionTitle>Progress by subject</SectionTitle>
          {withChapters.length === 0 ? (
            <EmptyState title="No chapters yet" text="Import your syllabus and update chapter statuses to see subject progress." />
          ) : (
            <ul className="space-y-3">
              {subjectRows.map(({ s, st: x }) => (
                <li key={s.id}>
                  <div className="mb-1 flex justify-between gap-2 text-[13px]">
                    <span className="truncate font-medium">{s.name}</span>
                    <span className="shrink-0 text-muted">{x.total ? `${x.completed}/${x.total} · ${x.percent}%` : "No chapters"}</span>
                  </div>
                  <ProgressBar value={x.percent} label={s.name} />
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="p-5">
          <SectionTitle>Chapter status distribution</SectionTitle>
          {st.total === 0 ? (
            <EmptyState title="Nothing to show yet" text="Add chapters to see how they are distributed across statuses." />
          ) : (
            <Donut
              parts={[
                { label: "Completed", value: st.completed, color: "var(--ok)" },
                { label: "In progress", value: st.inProgress, color: "var(--info)" },
                { label: "Needs revision", value: st.needsRevision, color: "var(--warn)" },
                { label: "Not started", value: st.notStarted, color: "var(--muted)" },
              ]}
            />
          )}
        </Card>

        <Card className="p-5">
          <SectionTitle>Completed vs remaining (by subject)</SectionTitle>
          {withChapters.length === 0 ? (
            <EmptyState title="No data yet" />
          ) : (
            <ul className="space-y-3">
              {withChapters.map(({ s, st: x }) => (
                <li key={s.id}>
                  <div className="mb-1 flex justify-between text-[13px]">
                    <span className="truncate font-medium">{s.name}</span>
                    <span className="text-muted">
                      {x.completed} done · {x.remaining} left
                    </span>
                  </div>
                  <div className="flex h-2.5 overflow-hidden rounded-full bg-surface2">
                    <div className="bg-ok transition-all" style={{ width: `${pct(x.completed, x.total)}%` }} />
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="p-5">
          <SectionTitle>Study time by subject</SectionTitle>
          {studyRows.length === 0 ? (
            <EmptyState title="No study time recorded" text="Complete a planner session or save a timer session to see where your time goes." />
          ) : (
            <BarList items={studyRows} />
          )}
          {hasActivity && <p className="mt-3 text-xs text-muted">Total recorded: {fmtDuration(a.totalMin)} (completed planner sessions + timer sessions)</p>}
        </Card>

        <Card className="p-5">
          <SectionTitle>Daily activity — last 14 days (minutes)</SectionTitle>
          {!hasActivity ? <EmptyState title="No activity yet" text="Tick off a study session or use the timer." /> : <ColumnChart data={a.daily} />}
        </Card>

        <Card className="p-5">
          <SectionTitle>Weekly activity — last 8 weeks (minutes)</SectionTitle>
          {!hasActivity ? <EmptyState title="No activity yet" text="Weekly totals appear once you record study time." /> : <ColumnChart data={a.weekly} />}
        </Card>
      </div>

      <Card className="p-5">
        <SectionTitle>Practice scores over time</SectionTitle>
        {a.scored.length < 2 ? (
          <EmptyState title="Record at least two scored practice results" text="Enter marks (or correct answers out of total) in Practice & Tests. A trend line appears once there are two or more." />
        ) : (
          <LineChart points={a.scored.map((p) => ({ label: fmtDate(p.date, { day: "numeric", month: "short" }), value: practicePct(p) ?? 0 }))} />
        )}
      </Card>
    </div>
  );
}
