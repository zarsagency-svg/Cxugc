"use client";

import { useMemo, useState } from "react";
import { useUI } from "@/components/Dialogs";
import { Badge, Button, Card, EmptyState, LineChart, PageHeader, SectionTitle, Select } from "@/components/ui";
import { useStore } from "@/lib/store";
import { PRACTICE_TYPES } from "@/lib/types";
import { fmtDate, fmtDuration, practicePct } from "@/lib/utils";

export default function PracticePage() {
  const { data, actions } = useStore();
  const { openPractice, confirm, toast } = useUI();
  const [subject, setSubject] = useState("");
  const [chapter, setChapter] = useState("");
  const [type, setType] = useState("");

  const chapters = data.chapters.filter((c) => !subject || c.subjectId === subject);
  const list = useMemo(
    () =>
      data.practice
        .filter((p) => (!subject || p.subjectId === subject) && (!chapter || p.chapterId === chapter) && (!type || p.type === type))
        .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0)),
    [data.practice, subject, chapter, type],
  );
  const scored = [...list].filter((p) => practicePct(p) != null).reverse();
  const avg = scored.length ? Math.round(scored.reduce((a, p) => a + (practicePct(p) ?? 0), 0) / scored.length) : null;
  const best = scored.length ? Math.max(...scored.map((p) => practicePct(p) ?? 0)) : null;
  const change = scored.length >= 2 ? Math.round((practicePct(scored[scored.length - 1]) ?? 0) - (practicePct(scored[0]) ?? 0)) : null;

  return (
    <div>
      <PageHeader
        title="Practice & Tests"
        subtitle="A log of your own practice and mock tests. Questions are not provided here — nothing is presented as official SEBA material."
        actions={<Button variant="primary" onClick={() => openPractice({ subjectId: subject, chapterId: chapter || null })}>＋ Record practice / test</Button>}
      />

      <Card className="mb-4 p-3 sm:p-4">
        <div className="grid gap-2 sm:grid-cols-3">
          <Select aria-label="Filter by subject" value={subject} onChange={(v) => { setSubject(v); setChapter(""); }} options={[{ value: "", label: "All subjects" }, ...data.subjects.map((s) => ({ value: s.id, label: s.name }))]} />
          <Select aria-label="Filter by chapter" value={chapter} onChange={setChapter} options={[{ value: "", label: "All chapters" }, ...chapters.map((c) => ({ value: c.id, label: c.name }))]} />
          <Select aria-label="Filter by practice type" value={type} onChange={setType} options={[{ value: "", label: "All types" }, ...PRACTICE_TYPES.map((t) => ({ value: t, label: t }))]} />
        </div>
      </Card>

      <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          ["Records", list.length],
          ["Average score", avg != null ? `${avg}%` : "—"],
          ["Best score", best != null ? `${best}%` : "—"],
          ["Change (first → latest)", change != null ? `${change > 0 ? "+" : ""}${change} pts` : "—"],
        ].map(([l, v]) => (
          <Card key={l} className="p-4">
            <p className="text-xs text-muted">{l}</p>
            <p className="text-2xl font-semibold tabular-nums">{v}</p>
          </Card>
        ))}
      </div>

      <Card className="mb-5 p-4">
        <SectionTitle>Scores over time</SectionTitle>
        {scored.length < 2 ? (
          <EmptyState title="Need at least two scored records" text="Record marks or correct answers for two or more sessions to compare results over time." />
        ) : (
          <LineChart points={scored.map((p) => ({ label: fmtDate(p.date, { day: "numeric", month: "short" }), value: practicePct(p) ?? 0 }))} />
        )}
      </Card>

      <SectionTitle>Records</SectionTitle>
      {list.length === 0 ? (
        <EmptyState title="No practice records" text={data.practice.length ? "Nothing matches these filters." : "Log your first MCQ set, textbook exercise or mock test."} action={<Button variant="primary" onClick={() => openPractice({})}>Record practice</Button>} />
      ) : (
        <ul className="space-y-2">
          {list.map((p) => {
            const v = practicePct(p);
            const ch = data.chapters.find((c) => c.id === p.chapterId);
            return (
              <li key={p.id} className="rounded-xl border border-line bg-surface p-3">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium">
                      {data.subjects.find((s) => s.id === p.subjectId)?.name}
                      {ch && <span className="text-muted"> · {ch.name}</span>}
                    </p>
                    <p className="mt-0.5 text-xs text-muted">
                      {fmtDate(p.date)} · {p.type}
                      {p.timeMin != null && ` · ${fmtDuration(p.timeMin)}`}
                      {p.total != null && ` · ${p.correct ?? "?"}/${p.total} correct`}
                      {p.marks != null && p.totalMarks != null && ` · ${p.marks}/${p.totalMarks} marks`}
                    </p>
                    {p.mistakes && <p className="mt-1.5 text-xs"><span className="text-muted">Mistakes: </span>{p.mistakes}</p>}
                    {p.notes && <p className="mt-1 text-xs text-muted">{p.notes}</p>}
                  </div>
                  <div className="flex items-center gap-2">
                    {v != null ? <Badge tone={v >= 75 ? "ok" : v >= 50 ? "warn" : "bad"} className="!text-sm">{v}%</Badge> : <Badge>No score</Badge>}
                    <Button size="sm" variant="ghost" aria-label="Edit record" onClick={() => openPractice(p)}>✐</Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      aria-label="Delete record"
                      onClick={() =>
                        confirm({
                          title: "Delete this practice record?",
                          text: "This also changes your analytics and weak-chapter detection.",
                          confirmLabel: "Delete",
                          onYes: () => {
                            actions.deletePractice(p.id);
                            toast("Practice record deleted");
                          },
                        })
                      }
                    >
                      🗑
                    </Button>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
