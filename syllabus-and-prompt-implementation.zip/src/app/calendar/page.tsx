"use client";

import { useState } from "react";
import { useUI } from "@/components/Dialogs";
import { Badge, Button, Card, PageHeader, cx } from "@/components/ui";
import { useStore } from "@/lib/store";
import { addDays, dateStr, fmtDuration, fmtShort, fmtTime, parseDate, startOfWeek, todayStr } from "@/lib/utils";

type Item = { key: string; kind: "study" | "revision" | "mock" | "deadline" | "important"; title: string; sub: string; done: boolean; open: () => void };

const dot: Record<Item["kind"], string> = {
  study: "bg-accent",
  revision: "bg-warn",
  mock: "bg-bad",
  deadline: "bg-info",
  important: "bg-ok",
};
const kindLabel: Record<Item["kind"], string> = { study: "Study", revision: "Revision", mock: "Mock test", deadline: "Deadline", important: "Important" };

export default function CalendarPage() {
  const { data } = useStore();
  const { openTask, openRevision, openEvent, openPractice } = useUI();
  const today = todayStr();
  const [view, setView] = useState<"month" | "week">("month");
  const [cursor, setCursor] = useState(today);
  const [selected, setSelected] = useState(today);

  const subj = (id: string) => data.subjects.find((s) => s.id === id)?.name ?? "";
  const chap = (id: string | null) => data.chapters.find((c) => c.id === id)?.name ?? "";

  const itemsFor = (d: string): Item[] => [
    ...data.tasks
      .filter((t) => t.date === d)
      .map<Item>((t) => ({ key: t.id, kind: "study", title: t.description || t.type, sub: `${subj(t.subjectId)}${t.start ? " · " + fmtTime(t.start) : ""} · ${fmtDuration(t.durationMin)}`, done: t.done, open: () => openTask(t) })),
    ...data.revisions
      .filter((r) => r.date === d)
      .map<Item>((r) => ({ key: r.id, kind: "revision", title: `${r.type}: ${chap(r.chapterId)}`, sub: subj(r.subjectId), done: r.done, open: () => openRevision(r) })),
    ...data.practice
      .filter((p) => p.date === d && p.type === "Mock test")
      .map<Item>((p) => ({ key: p.id, kind: "mock", title: `Mock test · ${subj(p.subjectId)}`, sub: "Recorded result", done: true, open: () => openPractice(p) })),
    ...data.events
      .filter((e) => e.date === d)
      .map<Item>((e) => ({ key: e.id, kind: e.kind, title: e.title, sub: e.notes, done: false, open: () => openEvent(e) })),
  ];

  const first = parseDate(cursor.slice(0, 8) + "01");
  const gridStart = startOfWeek(dateStr(first));
  const cells = Array.from({ length: 42 }, (_, i) => addDays(gridStart, i));
  const weekStart = startOfWeek(cursor);
  const week = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  const monthLabel = first.toLocaleDateString(undefined, { month: "long", year: "numeric" });

  const move = (dir: number) => {
    if (view === "week") setCursor(addDays(cursor, dir * 7));
    else {
      const d = parseDate(cursor);
      d.setDate(1);
      d.setMonth(d.getMonth() + dir);
      setCursor(dateStr(d));
    }
  };

  const selItems = itemsFor(selected);

  return (
    <div>
      <PageHeader
        title="Calendar"
        subtitle="Study sessions, revisions, mock tests and your own deadlines. Only dates you add are shown — no exam dates are pre-filled."
        actions={<Button variant="primary" onClick={() => openEvent({ date: selected })}>＋ Add date / deadline</Button>}
      />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <Button size="sm" onClick={() => move(-1)} aria-label="Previous">‹</Button>
        <h2 className="min-w-40 text-center text-base font-semibold">{view === "month" ? monthLabel : `Week of ${fmtShort(weekStart)}`}</h2>
        <Button size="sm" onClick={() => move(1)} aria-label="Next">›</Button>
        <Button size="sm" onClick={() => { setCursor(today); setSelected(today); }}>Today</Button>
        <div className="ml-auto flex rounded-xl bg-surface2 p-1">
          {(["month", "week"] as const).map((v) => (
            <button key={v} onClick={() => setView(v)} aria-pressed={view === v} className={cx("min-h-9 rounded-lg px-3 text-sm font-medium capitalize", view === v ? "bg-surface shadow-sm" : "text-muted")}>
              {v}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="p-2 sm:p-3 lg:col-span-2">
          <div className="grid grid-cols-7 pb-1 text-center text-[11px] font-medium text-muted">
            {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => (
              <div key={d}>{d}</div>
            ))}
          </div>
          {view === "month" ? (
            <div className="grid grid-cols-7 gap-1">
              {cells.map((d) => {
                const items = itemsFor(d);
                const inMonth = d.slice(0, 7) === cursor.slice(0, 7);
                return (
                  <button
                    key={d}
                    onClick={() => setSelected(d)}
                    aria-label={`${fmtShort(d)}, ${items.length} item${items.length === 1 ? "" : "s"}`}
                    aria-pressed={selected === d}
                    className={cx(
                      "flex min-h-14 flex-col items-center gap-1 rounded-xl border p-1 text-sm transition sm:min-h-20 sm:items-start sm:p-2",
                      selected === d ? "border-accent bg-accent-soft" : "border-transparent hover:bg-surface2",
                      !inMonth && "opacity-40",
                    )}
                  >
                    <span className={cx("grid h-6 w-6 place-items-center rounded-full text-[13px]", d === today && "bg-accent font-semibold text-accent-fg")}>{parseDate(d).getDate()}</span>
                    <span className="flex flex-wrap justify-center gap-0.5 sm:justify-start">
                      {items.slice(0, 4).map((it) => (
                        <span key={it.key} className={cx("h-1.5 w-1.5 rounded-full", dot[it.kind])} />
                      ))}
                      {items.length > 4 && <span className="text-[9px] leading-none text-muted">+{items.length - 4}</span>}
                    </span>
                  </button>
                );
              })}
            </div>
          ) : (
            <ul className="space-y-1.5">
              {week.map((d) => {
                const items = itemsFor(d);
                return (
                  <li key={d}>
                    <button onClick={() => setSelected(d)} className={cx("w-full rounded-xl border p-3 text-left", selected === d ? "border-accent bg-accent-soft" : "border-line hover:bg-surface2")}>
                      <div className="flex items-center justify-between">
                        <span className={cx("text-sm font-semibold", d === today && "text-accent")}>{fmtShort(d)}</span>
                        <span className="text-xs text-muted">{items.length} item{items.length === 1 ? "" : "s"}</span>
                      </div>
                      {items.slice(0, 3).map((it) => (
                        <p key={it.key} className="mt-1 flex items-center gap-2 truncate text-[13px] text-muted">
                          <span className={cx("h-2 w-2 shrink-0 rounded-full", dot[it.kind])} />
                          <span className="truncate">{it.title}</span>
                        </p>
                      ))}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 px-1 text-[11px] text-muted">
            {(Object.keys(dot) as Item["kind"][]).map((k) => (
              <span key={k} className="flex items-center gap-1.5">
                <span className={cx("h-2 w-2 rounded-full", dot[k])} />
                {kindLabel[k]}
              </span>
            ))}
          </div>
        </Card>

        <Card className="p-4">
          <h2 className="text-base font-semibold">{fmtShort(selected)}</h2>
          <p className="mb-3 text-xs text-muted">{selected === today ? "Today" : parseDate(selected).toLocaleDateString(undefined, { year: "numeric" })}</p>
          <div className="mb-4 grid grid-cols-3 gap-2">
            <Button size="sm" onClick={() => openTask({ date: selected })}>＋ Study</Button>
            <Button size="sm" onClick={() => openRevision({ date: selected })}>＋ Revision</Button>
            <Button size="sm" onClick={() => openEvent({ date: selected })}>＋ Date</Button>
          </div>
          {selItems.length === 0 ? (
            <p className="rounded-xl border border-dashed border-line p-4 text-center text-[13px] text-muted">Nothing on this date yet.</p>
          ) : (
            <ul className="space-y-2">
              {selItems.map((it) => (
                <li key={it.key}>
                  <button onClick={it.open} className="flex w-full items-start gap-3 rounded-xl bg-surface2 p-3 text-left hover:opacity-90">
                    <span className={cx("mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full", dot[it.kind])} />
                    <span className="min-w-0 flex-1">
                      <span className={cx("block truncate text-sm font-medium", it.done && "text-muted line-through")}>{it.title}</span>
                      {it.sub && <span className="block truncate text-xs text-muted">{it.sub}</span>}
                    </span>
                    <Badge>{kindLabel[it.kind]}</Badge>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
