"use client";

import { useRef, useState } from "react";
import { useUI } from "@/components/Dialogs";
import { Button, Card, Field, Modal, PageHeader, SectionTitle } from "@/components/ui";
import { useStore } from "@/lib/store";
import type { AppData } from "@/lib/types";
import { csvCell, download, fmtDate, nextRevisionOf, statusLabel, todayStr, understandingLabel, validateImport, weakReasons } from "@/lib/utils";

export default function SettingsPage() {
  const { data, actions } = useStore();
  const { toast } = useUI();
  const s = data.settings;
  const fileRef = useRef<HTMLInputElement>(null);
  const [pending, setPending] = useState<AppData | null>(null);
  const [resetOpen, setResetOpen] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const [intervals, setIntervals] = useState(s.revision.intervals.join(", "));

  const exportJson = () => {
    const payload = { app: "hslc-2027-planner", exportedAt: new Date().toISOString(), ...data };
    download(`hslc-2027-backup-${todayStr()}.json`, JSON.stringify(payload, null, 2), "application/json");
    toast("Backup downloaded");
  };

  const exportCsv = () => {
    if (!data.chapters.length) return toast("No chapters to export yet", "error");
    const head = ["Subject", "Unit", "Chapter", "Status", "Understanding", "Priority", "Weak", "Last studied", "Next revision", "Est. remaining (min)", "Actual (min)", "Notes", "Remarks"];
    const rows = data.chapters.map((c) => [
      data.subjects.find((x) => x.id === c.subjectId)?.name,
      c.unit,
      c.name,
      statusLabel(c.status),
      understandingLabel(c.understanding),
      c.priority,
      weakReasons(c, data.practice).length ? "Yes" : "No",
      c.lastStudied ?? "",
      nextRevisionOf(c, data.revisions) ?? "",
      c.estRemainingMin ?? "",
      c.actualMin,
      c.notes,
      c.remarks,
    ]);
    download(`hslc-2027-chapter-progress-${todayStr()}.csv`, [head, ...rows].map((r) => r.map(csvCell).join(",")).join("\n"), "text/csv");
    toast("CSV downloaded");
  };

  const onFile = async (f: File | undefined) => {
    if (!f) return;
    try {
      const raw = JSON.parse(await f.text());
      const res = validateImport(raw);
      if (!res.ok) return toast(res.error, "error");
      setPending(res.data);
    } catch {
      toast("That file is not valid JSON.", "error");
    }
    if (fileRef.current) fileRef.current.value = "";
  };

  const saveIntervals = () => {
    const nums = intervals.split(/[,\s]+/).filter(Boolean).map(Number);
    if (nums.some((n) => !Number.isInteger(n) || n < 1 || n > 365)) return toast("Intervals must be whole days between 1 and 365, e.g. 1, 3, 7, 14", "error");
    actions.updateSettings({ revision: { ...s.revision, intervals: nums } });
    toast("Revision intervals saved");
  };

  const hours = Math.floor(s.dailyTargetMin / 60);
  const mins = s.dailyTargetMin % 60;
  const setTarget = (h: number, m: number) => actions.updateSettings({ dailyTargetMin: Math.max(0, Math.min(1440, h * 60 + m)) });

  return (
    <div className="space-y-5">
      <PageHeader title="Settings" subtitle="Preferences are saved automatically in this browser." />

      <Card className="p-5">
        <SectionTitle>Appearance</SectionTitle>
        <div className="flex gap-2" role="radiogroup" aria-label="Theme">
          {(["light", "dark"] as const).map((t) => (
            <Button key={t} variant={s.theme === t ? "primary" : "secondary"} role="radio" aria-checked={s.theme === t} onClick={() => actions.updateSettings({ theme: t })}>
              {t === "light" ? "☀ Light" : "☾ Dark"}
            </Button>
          ))}
        </div>
      </Card>

      <Card className="space-y-4 p-5">
        <SectionTitle>Exam & study goals</SectionTitle>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Exam target date" hint="Leave empty until the official date is announced. The dashboard then counts down to February 2027 without claiming an exact date.">
            <div className="flex gap-2">
              <input type="date" className="input" value={s.examDate ?? ""} onChange={(e) => { actions.updateSettings({ examDate: e.target.value || null }); toast(e.target.value ? "Exam date saved" : "Exam date cleared", "success"); }} />
              {s.examDate && <Button onClick={() => { actions.updateSettings({ examDate: null }); toast("Exam date cleared"); }}>Clear</Button>}
            </div>
          </Field>
          <Field label="Personal daily study goal" hint="A goal for you — not a requirement. Set 0 to turn it off.">
            <div className="flex items-center gap-2">
              <input type="number" min={0} max={24} aria-label="Hours" className="input" value={hours} onChange={(e) => setTarget(Number(e.target.value) || 0, mins)} />
              <span className="text-sm text-muted">h</span>
              <input type="number" min={0} max={59} step={5} aria-label="Minutes" className="input" value={mins} onChange={(e) => setTarget(hours, Math.min(59, Number(e.target.value) || 0))} />
              <span className="text-sm text-muted">min</span>
            </div>
          </Field>
        </div>
      </Card>

      <Card className="space-y-4 p-5">
        <SectionTitle>Pomodoro (optional)</SectionTitle>
        <div className="grid grid-cols-2 gap-4 sm:max-w-md">
          <Field label="Study block (min)">
            <input type="number" min={1} max={180} className="input" value={s.pomodoro.study} onChange={(e) => actions.updateSettings({ pomodoro: { ...s.pomodoro, study: Math.max(1, Math.min(180, Number(e.target.value) || 1)) } })} />
          </Field>
          <Field label="Break (min)">
            <input type="number" min={1} max={60} className="input" value={s.pomodoro.brk} onChange={(e) => actions.updateSettings({ pomodoro: { ...s.pomodoro, brk: Math.max(1, Math.min(60, Number(e.target.value) || 1)) } })} />
          </Field>
        </div>
        <p className="text-xs text-muted">Pomodoro only applies when you switch it on in the Study Timer.</p>
      </Card>

      <Card className="space-y-4 p-5">
        <SectionTitle>Revision preferences</SectionTitle>
        <label className="flex min-h-10 items-center gap-2 text-sm">
          <input type="checkbox" className="h-4 w-4 accent-[var(--accent)]" checked={s.revision.suggest} onChange={(e) => actions.updateSettings({ revision: { ...s.revision, suggest: e.target.checked } })} />
          Show suggested revision intervals when scheduling
        </label>
        <div className="flex max-w-md items-end gap-2">
          <Field label="Suggested intervals (days after today)" className="flex-1">
            <input className="input" value={intervals} onChange={(e) => setIntervals(e.target.value)} />
          </Field>
          <Button onClick={saveIntervals}>Save</Button>
        </div>
        <p className="text-xs text-muted">Suggestions are only quick-pick buttons. You always choose your own dates.</p>
      </Card>

      <Card className="space-y-4 p-5">
        <SectionTitle>Your data</SectionTitle>
        <p className="rounded-xl bg-warn-soft px-3 py-2.5 text-[13px] text-warn">
          Your progress is stored only in this browser (localStorage). It is <strong>not</strong> synced to the cloud. Clearing browser data, using private mode, or switching browser/device can remove or hide it — export a backup regularly.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button variant="primary" onClick={exportJson}>⇩ Export backup (JSON)</Button>
          <Button onClick={exportCsv}>⇩ Chapter progress (CSV)</Button>
          <Button onClick={() => fileRef.current?.click()}>⇪ Import backup…</Button>
          <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" aria-label="Import backup file" onChange={(e) => onFile(e.target.files?.[0])} />
        </div>
        <div className="border-t border-line pt-4">
          <p className="mb-2 text-sm font-medium text-bad">Danger zone</p>
          <Button variant="danger" onClick={() => { setConfirmText(""); setResetOpen(true); }}>Reset all data…</Button>
        </div>
      </Card>

      <Card className="p-5">
        <SectionTitle>About</SectionTitle>
        <p className="text-sm text-muted">
          Class 10 HSLC 2027 Personal Exam Planner for ASSEB Division-I (SEBA), Assam. Six subjects: General Mathematics, Advanced Mathematics, General Science, Social Science, Assamese (MIL) and English (Second Language). No official exam dates are built in; syllabus chapters come only from what you import.
        </p>
      </Card>

      {pending && (
        <Modal
          open
          onClose={() => setPending(null)}
          title="Replace your data with this backup?"
          footer={
            <>
              <Button onClick={() => setPending(null)}>Cancel</Button>
              <Button
                variant="danger"
                onClick={() => {
                  actions.replaceAll(pending);
                  setPending(null);
                  toast("Backup restored");
                }}
              >
                Replace my data
              </Button>
            </>
          }
        >
          <p className="mb-3 text-sm text-muted">The file is valid. Importing will <strong>replace everything</strong> currently saved in this browser.</p>
          <ul className="grid grid-cols-2 gap-2 text-[13px]">
            {[
              ["Chapters", pending.chapters.length],
              ["Study sessions", pending.tasks.length],
              ["Revisions", pending.revisions.length],
              ["Practice records", pending.practice.length],
              ["Notes", pending.notes.length],
              ["Timer sessions", pending.timerLogs.length],
            ].map(([l, v]) => (
              <li key={l} className="rounded-lg bg-surface2 px-3 py-2">
                <span className="text-muted">{l}:</span> <strong>{v}</strong>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-xs text-muted">Current data: {data.chapters.length} chapters, {data.tasks.length} sessions. Exam date in file: {pending.settings.examDate ? fmtDate(pending.settings.examDate) : "not set"}.</p>
        </Modal>
      )}

      {resetOpen && (
        <Modal
          open
          onClose={() => setResetOpen(false)}
          title="Reset all data"
          footer={
            <>
              <Button onClick={() => setResetOpen(false)}>Cancel</Button>
              <Button
                variant="danger"
                disabled={confirmText.trim().toUpperCase() !== "RESET"}
                onClick={() => {
                  actions.resetAll();
                  setResetOpen(false);
                  toast("All data has been reset", "info");
                }}
              >
                Delete everything
              </Button>
            </>
          }
        >
          <p className="mb-3 text-sm text-muted">This permanently deletes all chapters, progress, sessions, revisions, practice records, notes and settings from this browser. Consider exporting a backup first.</p>
          <Field label="Type RESET to confirm">
            <input className="input" value={confirmText} onChange={(e) => setConfirmText(e.target.value)} autoComplete="off" />
          </Field>
        </Modal>
      )}
    </div>
  );
}
