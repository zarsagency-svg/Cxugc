"use client";

import { Fragment, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { SubjectChapterFields, useUI } from "@/components/Dialogs";
import { Badge, Button, Card, EmptyState, Field, Modal, PageHeader, Select } from "@/components/ui";
import { useStore } from "@/lib/store";
import type { Note } from "@/lib/types";
import { fmtDate } from "@/lib/utils";

function inline(text: string): ReactNode[] {
  return text.split(/(\*\*[^*]+\*\*)/g).map((p, i) => (p.startsWith("**") && p.endsWith("**") && p.length > 4 ? <strong key={i}>{p.slice(2, -2)}</strong> : <Fragment key={i}>{p}</Fragment>));
}

function RenderNote({ text }: { text: string }) {
  const lines = text.split("\n");
  const out: ReactNode[] = [];
  let bullets: string[] = [];
  const flush = () => {
    if (bullets.length) {
      out.push(
        <ul key={`u${out.length}`}>
          {bullets.map((b, i) => (
            <li key={i}>{inline(b)}</li>
          ))}
        </ul>,
      );
      bullets = [];
    }
  };
  lines.forEach((l, i) => {
    const b = l.match(/^\s*[-*•]\s+(.*)$/);
    if (b) return void bullets.push(b[1]);
    flush();
    const h = l.match(/^(#{1,3})\s+(.*)$/);
    if (h) {
      const Tag = (`h${h[1].length}`) as "h1" | "h2" | "h3";
      out.push(<Tag key={i}>{inline(h[2])}</Tag>);
    } else if (l.trim()) out.push(<p key={i}>{inline(l)}</p>);
  });
  flush();
  return <div className="prose-note text-sm">{out}</div>;
}

export default function NotesPage() {
  const { data, actions } = useStore();
  const { focus, setFocus, confirm, toast } = useUI();
  const [q, setQ] = useState("");
  const [subject, setSubject] = useState("");
  const [editing, setEditing] = useState<Partial<Note> | null>(null);

  useEffect(() => {
    if (focus.noteId) {
      const n = data.notes.find((x) => x.id === focus.noteId);
      if (n) setEditing(n);
      setFocus({});
    }
  }, [focus.noteId, data.notes, setFocus]);

  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return data.notes
      .filter((n) => (!subject || n.subjectId === subject) && (!s || n.title.toLowerCase().includes(s) || n.content.toLowerCase().includes(s)))
      .sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1));
  }, [data.notes, q, subject]);

  return (
    <div>
      <PageHeader
        title="Notes"
        subtitle="Personal notes for any subject or chapter. Use # headings, **bold** and - bullet points."
        actions={<Button variant="primary" onClick={() => setEditing({ title: "", content: "", subjectId: null, chapterId: null })}>＋ New note</Button>}
      />
      <Card className="mb-4 grid gap-2 p-3 sm:grid-cols-3 sm:p-4">
        <input type="search" aria-label="Search notes" className="input sm:col-span-2" placeholder="Search notes…" value={q} onChange={(e) => setQ(e.target.value)} />
        <Select aria-label="Filter by subject" value={subject} onChange={setSubject} options={[{ value: "", label: "All subjects" }, ...data.subjects.map((s) => ({ value: s.id, label: s.name }))]} />
      </Card>
      {list.length === 0 ? (
        <EmptyState title={data.notes.length ? "No notes match" : "No notes yet"} text="Notes are optional — you can track chapters without them." action={<Button variant="primary" onClick={() => setEditing({ title: "", content: "", subjectId: null, chapterId: null })}>Write a note</Button>} />
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {list.map((n) => (
            <Card key={n.id} className="flex flex-col p-4">
              <div className="mb-2 flex items-start justify-between gap-2">
                <h3 className="text-[15px] font-semibold leading-snug">{n.title || "Untitled"}</h3>
                <div className="flex shrink-0 gap-1">
                  <Button size="sm" variant="ghost" aria-label="Edit note" onClick={() => setEditing(n)}>✐</Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    aria-label="Delete note"
                    onClick={() =>
                      confirm({
                        title: "Delete this note?",
                        text: "This cannot be undone (unless you have an exported backup).",
                        confirmLabel: "Delete",
                        onYes: () => {
                          actions.deleteNote(n.id);
                          toast("Note deleted");
                        },
                      })
                    }
                  >
                    🗑
                  </Button>
                </div>
              </div>
              <div className="mb-2 flex flex-wrap gap-1.5">
                {n.subjectId && <Badge tone="accent">{data.subjects.find((s) => s.id === n.subjectId)?.name}</Badge>}
                {n.chapterId && <Badge>{data.chapters.find((c) => c.id === n.chapterId)?.name}</Badge>}
              </div>
              <div className="max-h-48 overflow-hidden">
                <RenderNote text={n.content} />
              </div>
              <p className="mt-3 text-[11px] text-muted">
                Created {fmtDate(n.createdAt.slice(0, 10))} · edited {new Date(n.updatedAt).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}
              </p>
            </Card>
          ))}
        </div>
      )}
      {editing && <NoteEditor note={editing} onClose={() => setEditing(null)} />}
    </div>
  );
}

function NoteEditor({ note, onClose }: { note: Partial<Note>; onClose: () => void }) {
  const { actions } = useStore();
  const { toast } = useUI();
  const [title, setTitle] = useState(note.title ?? "");
  const [content, setContent] = useState(note.content ?? "");
  const [sid, setSid] = useState(note.subjectId ?? "");
  const [cid, setCid] = useState<string | null>(note.chapterId ?? null);
  const [preview, setPreview] = useState(false);
  const ta = useRef<HTMLTextAreaElement>(null);

  const wrap = (before: string, after = "") => {
    const el = ta.current;
    if (!el) return;
    const { selectionStart: s, selectionEnd: e } = el;
    const sel = content.slice(s, e) || "text";
    setContent(content.slice(0, s) + before + sel + after + content.slice(e));
    setTimeout(() => el.focus(), 0);
  };

  const save = () => {
    if (!title.trim() && !content.trim()) return toast("Write a title or some content first", "error");
    actions.saveNote({ id: note.id, title: title.trim(), content, subjectId: sid || null, chapterId: cid });
    toast(note.id ? "Note updated" : "Note saved");
    onClose();
  };

  return (
    <Modal
      open
      wide
      onClose={onClose}
      title={note.id ? "Edit note" : "New note"}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={save}>Save note</Button>
        </>
      }
    >
      <div className="space-y-3">
        <Field label="Title">
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <SubjectChapterFields subjectId={sid} chapterId={cid} onChange={(s, c) => { setSid(s); setCid(c); }} />
        <div>
          <div className="mb-1 flex flex-wrap items-center gap-1.5">
            <span className="mr-auto text-[13px] font-medium text-muted">Content</span>
            <Button size="sm" onClick={() => wrap("## ")} aria-label="Heading">H</Button>
            <Button size="sm" onClick={() => wrap("**", "**")} aria-label="Bold"><strong>B</strong></Button>
            <Button size="sm" onClick={() => wrap("\n- ")} aria-label="Bullet">•</Button>
            <Button size="sm" variant={preview ? "primary" : "secondary"} onClick={() => setPreview(!preview)}>{preview ? "Edit" : "Preview"}</Button>
          </div>
          {preview ? (
            <div className="min-h-40 rounded-xl border border-line p-3">
              <RenderNote text={content || "_Nothing to preview_"} />
            </div>
          ) : (
            <textarea ref={ta} aria-label="Note content" className="input !min-h-52" value={content} onChange={(e) => setContent(e.target.value)} />
          )}
        </div>
      </div>
    </Modal>
  );
}
