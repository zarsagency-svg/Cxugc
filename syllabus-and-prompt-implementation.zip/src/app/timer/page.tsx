"use client";

import { useEffect, useRef, useState } from "react";
import { useUI, SubjectChapterFields } from "@/components/Dialogs";
import { Badge, Button, Card, EmptyState, Field, Modal, PageHeader, SectionTitle } from "@/components/ui";
import { useStore } from "@/lib/store";
import type { TimerState } from "@/lib/types";
import { defaultTimer, fmtClock, fmtDuration, isoToLocalDate, todayStr } from "@/lib/utils";

export default function TimerPage() {
  const { data, actions } = useStore();
  const { toast, confirm } = useUI();
  const t = data.timer;
  const { study, brk } = data.settings.pomodoro;
  const [now, setNow] = useState(() => Date.now());
  const [saving, setSaving] = useState(false);
  const [notes, setNotes] = useState("");
  const latest = useRef(t);
  latest.current = t;
  const lastSwitch = useRef(0);

  const running = t.runningSince != null;
  const seg = running ? Math.max(0, now - (t.runningSince as number)) : 0;
  const totalStudy = t.studyMs + (t.phase === "study" ? seg : 0);
  const phaseElapsed = t.phaseMs + seg;
  const phaseLen = (t.phase === "study" ? study : brk) * 60000;

  // tick
  useEffect(() => {
    if (!running) return;
    const i = setInterval(() => {
      const n = Date.now();
      setNow(n);
      const cur = latest.current;
      if (cur.pomodoro && cur.runningSince != null) {
        const len = (cur.phase === "study" ? study : brk) * 60000;
        const el = cur.phaseMs + (n - cur.runningSince);
        if (el >= len && n - lastSwitch.current > 2000) {
          lastSwitch.current = n;
          const next = cur.phase === "study" ? "break" : "study";
          actions.setTimer((x) => {
            if (x.runningSince == null) return {};
            const s = Date.now() - x.runningSince;
            const l = (x.phase === "study" ? study : brk) * 60000;
            if (x.phaseMs + s < l) return {};
            return { studyMs: x.phase === "study" ? x.studyMs + s : x.studyMs, phaseMs: 0, runningSince: Date.now(), phase: x.phase === "study" ? "break" : "study" };
          });
          toast(next === "break" ? `Study block done — take a ${brk}-minute break` : "Break over — back to studying", "info");
        }
      }
    }, 500);
    return () => clearInterval(i);
  }, [running, study, brk, actions, toast]);

  const commit = (x: TimerState): Partial<TimerState> => {
    if (x.runningSince == null) return {};
    const s = Date.now() - x.runningSince;
    return { studyMs: x.phase === "study" ? x.studyMs + s : x.studyMs, phaseMs: x.phaseMs + s, runningSince: null };
  };

  const start = () => {
    if (!t.subjectId) return toast("Choose a subject before starting", "error");
    setNow(Date.now());
    actions.setTimer({ active: true, startedAt: new Date().toISOString(), studyMs: 0, phaseMs: 0, phase: "study", runningSince: Date.now() });
  };
  const pause = () => actions.setTimer((x) => commit(x));
  const resume = () => {
    setNow(Date.now());
    actions.setTimer({ runningSince: Date.now() });
  };
  const stop = () => {
    actions.setTimer((x) => commit(x));
    setNotes("");
    setSaving(true);
  };
  const reset = () =>
    confirm({
      title: "Reset the timer?",
      text: "The current time will be discarded and not saved.",
      confirmLabel: "Reset",
      onYes: () => {
        actions.setTimer({ ...defaultTimer(), subjectId: t.subjectId, chapterId: t.chapterId, pomodoro: t.pomodoro });
        toast("Timer reset", "info");
      },
    });

  const saveSession = () => {
    const secs = Math.round(t.studyMs / 1000);
    if (secs < 1) {
      toast("Nothing to save — no study time recorded", "error");
      return;
    }
    actions.addTimerLog({ subjectId: t.subjectId, chapterId: t.chapterId, startedAt: t.startedAt ?? new Date().toISOString(), durationSec: secs, notes });
    actions.setTimer({ ...defaultTimer(), subjectId: t.subjectId, chapterId: t.chapterId, pomodoro: t.pomodoro });
    setSaving(false);
    toast(`Saved ${fmtDuration(secs / 60)} study session`);
  };

  const today = todayStr();
  const logs = [...data.timerLogs].sort((a, b) => (a.startedAt < b.startedAt ? 1 : -1));
  const todaySecs = logs.filter((l) => isoToLocalDate(l.startedAt) === today).reduce((a, l) => a + l.durationSec, 0);

  const display = t.pomodoro && t.active ? Math.max(0, phaseLen - phaseElapsed) : totalStudy;

  return (
    <div>
      <PageHeader title="Study Timer" subtitle="Optional. Time is based on the clock, so it stays accurate even if your phone sleeps or you switch tabs." />
      <div className="grid gap-5 lg:grid-cols-5">
        <Card className="p-5 lg:col-span-3">
          <div className="text-center">
            <div className="mb-2 flex justify-center gap-2">
              {t.pomodoro && t.active ? <Badge tone={t.phase === "study" ? "accent" : "ok"}>{t.phase === "study" ? "Study block" : "Break"}</Badge> : <Badge>{t.active ? (running ? "Running" : "Paused") : "Ready"}</Badge>}
              {t.pomodoro && <Badge tone="info">Pomodoro {study}/{brk} min</Badge>}
            </div>
            <p className="font-mono text-6xl font-semibold tabular-nums tracking-tight sm:text-7xl" aria-live="off">
              {fmtClock(display)}
            </p>
            {t.pomodoro && t.active && <p className="mt-1 text-xs text-muted">Studied so far: {fmtClock(totalStudy)}</p>}
          </div>

          <div className="mt-6 flex flex-wrap justify-center gap-2">
            {!t.active && (
              <Button variant="primary" className="min-w-32" onClick={start}>
                ▶ Start
              </Button>
            )}
            {t.active && running && (
              <Button className="min-w-32" onClick={pause}>
                ⏸ Pause
              </Button>
            )}
            {t.active && !running && (
              <Button variant="primary" className="min-w-32" onClick={resume}>
                ▶ Resume
              </Button>
            )}
            {t.active && (
              <Button variant="danger" onClick={stop}>
                ■ Stop &amp; save
              </Button>
            )}
            {(t.active || t.studyMs > 0) && <Button onClick={reset}>↺ Reset</Button>}
          </div>

          <div className="mt-6 space-y-3 border-t border-line pt-5">
            <div className={t.active ? "pointer-events-none opacity-60" : ""}>
              <SubjectChapterFields subjectId={t.subjectId} chapterId={t.chapterId} onChange={(s, c) => actions.setTimer({ subjectId: s, chapterId: c })} />
            </div>
            <label className="flex min-h-10 items-center gap-2 text-sm">
              <input type="checkbox" className="h-4 w-4 accent-[var(--accent)]" checked={t.pomodoro} disabled={t.active} onChange={(e) => actions.setTimer({ pomodoro: e.target.checked })} />
              Use Pomodoro mode (optional) — {study} min study / {brk} min break. Change in Settings.
            </label>
          </div>
        </Card>

        <Card className="p-4 lg:col-span-2">
          <SectionTitle>Saved sessions</SectionTitle>
          <p className="mb-3 text-[13px] text-muted">Today: <strong className="text-fg">{fmtDuration(todaySecs / 60)}</strong></p>
          {logs.length === 0 ? (
            <EmptyState title="No timer sessions yet" text="Stop the timer to save a session." />
          ) : (
            <ul className="max-h-[420px] space-y-2 overflow-y-auto">
              {logs.slice(0, 30).map((l) => (
                <li key={l.id} className="flex items-start justify-between gap-2 rounded-xl bg-surface2 p-3 text-[13px]">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{data.subjects.find((s) => s.id === l.subjectId)?.name}</p>
                    <p className="truncate text-xs text-muted">
                      {data.chapters.find((c) => c.id === l.chapterId)?.name ?? "No chapter"} · {new Date(l.startedAt).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}
                    </p>
                    {l.notes && <p className="mt-1 text-xs">{l.notes}</p>}
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <span className="font-semibold">{fmtDuration(l.durationSec / 60)}</span>
                    <Button
                      size="sm"
                      variant="ghost"
                      aria-label="Delete session"
                      onClick={() =>
                        confirm({
                          title: "Delete this timer session?",
                          text: "The logged time will be removed from analytics. Chapter study-time totals are not changed automatically.",
                          confirmLabel: "Delete",
                          onYes: () => {
                            actions.deleteTimerLog(l.id);
                            toast("Session deleted");
                          },
                        })
                      }
                    >
                      🗑
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      {saving && (
        <Modal
          open
          onClose={() => setSaving(false)}
          title="Save study session"
          footer={
            <>
              <Button onClick={() => setSaving(false)}>Keep paused</Button>
              <Button variant="primary" onClick={saveSession}>
                Save session
              </Button>
            </>
          }
        >
          <div className="space-y-3">
            <p className="text-sm">
              <strong>{data.subjects.find((s) => s.id === t.subjectId)?.name}</strong>
              {t.chapterId && <> · {data.chapters.find((c) => c.id === t.chapterId)?.name}</>}
            </p>
            <p className="text-3xl font-semibold tabular-nums">{fmtClock(t.studyMs)}</p>
            <Field label="Session notes (optional)">
              <textarea className="input" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="What did you cover?" />
            </Field>
          </div>
        </Modal>
      )}
    </div>
  );
}
