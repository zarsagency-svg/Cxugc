"use client";

import { useMemo, useState } from "react";
import { useUI } from "@/components/Dialogs";
import { Badge, Button, Card, EmptyState, PageHeader, PriorityBadge, Select, StatusBadge, UnderstandingBadge } from "@/components/ui";
import { useStore } from "@/lib/store";
import { UNDERSTANDINGS } from "@/lib/types";
import { fmtDate, latestPractice, nextRevisionOf, practicePct, priorityRank, understandingRank, weakReasons } from "@/lib/utils";

export default function WeakPage() {
  const { data, actions } = useStore();
  const { openRevision, openPractice, openChapter, toast } = useUI();
  const [sort, setSort] = useState("priority");

  const weak = useMemo(() => {
    const list = data.chapters
      .map((c) => ({ c, reasons: weakReasons(c, data.practice) }))
      .filter((x) => x.reasons.length > 0);
    list.sort((a, b) =>
      sort === "priority"
        ? priorityRank(b.c.priority) - priorityRank(a.c.priority) || (understandingRank(a.c.understanding) || 9) - (understandingRank(b.c.understanding) || 9)
        : sort === "understanding"
          ? (understandingRank(a.c.understanding) || 9) - (understandingRank(b.c.understanding) || 9)
          : b.reasons.length - a.reasons.length,
    );
    return list;
  }, [data, sort]);

  return (
    <div>
      <PageHeader
        title="Weak Chapters"
        subtitle="A chapter appears here if it is rated Very Weak/Weak, marked weak by you, set to Needs Revision, or your last two practice scores average below 50%."
        actions={
          <Select
            aria-label="Sort weak chapters"
            className="!w-56"
            value={sort}
            onChange={setSort}
            options={[
              { value: "priority", label: "Sort: Priority" },
              { value: "understanding", label: "Sort: Weakest understanding" },
              { value: "reasons", label: "Sort: Most reasons" },
            ]}
          />
        }
      />
      {weak.length === 0 ? (
        <EmptyState title="No weak chapters" text="Rate a chapter Weak or Very Weak, mark it as weak, or record low practice scores, and it will show up here. Improve the rating and it leaves this list automatically — your history stays." />
      ) : (
        <ul className="space-y-3">
          {weak.map(({ c, reasons }) => {
            const lp = latestPractice(c.id, data.practice);
            return (
              <li key={c.id}>
                <Card className="p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div className="min-w-0">
                      <button onClick={() => openChapter(c.id)} className="text-left text-[15px] font-semibold hover:text-accent">
                        {c.name}
                      </button>
                      <p className="text-xs text-muted">{data.subjects.find((s) => s.id === c.subjectId)?.name}</p>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      <UnderstandingBadge value={c.understanding} />
                      <StatusBadge status={c.status} />
                      <PriorityBadge value={c.priority} />
                    </div>
                  </div>
                  <dl className="mt-3 grid grid-cols-3 gap-3 text-[13px]">
                    <div><dt className="text-xs text-muted">Last studied</dt><dd className="font-medium">{fmtDate(c.lastStudied)}</dd></div>
                    <div><dt className="text-xs text-muted">Next revision</dt><dd className="font-medium">{fmtDate(nextRevisionOf(c, data.revisions))}</dd></div>
                    <div><dt className="text-xs text-muted">Latest practice</dt><dd className="font-medium">{lp ? `${practicePct(lp)}%` : "—"}</dd></div>
                  </dl>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {reasons.map((r) => (
                      <Badge key={r} tone="bad">{r}</Badge>
                    ))}
                  </div>
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    <Button
                      size="sm"
                      variant="primary"
                      onClick={() => {
                        actions.setStatus(c.id, "in_progress");
                        toast(`Revising “${c.name}” — status set to In Progress`);
                      }}
                    >
                      ▶ Revise now
                    </Button>
                    <Button size="sm" onClick={() => openPractice({ subjectId: c.subjectId, chapterId: c.id })}>✎ Practice questions</Button>
                    <Button size="sm" onClick={() => openRevision({ subjectId: c.subjectId, chapterId: c.id })}>↻ Schedule revision</Button>
                    <Select
                      aria-label={`Update understanding for ${c.name}`}
                      className="!min-h-9 !w-44 !text-[13px]"
                      value={c.understanding ?? ""}
                      onChange={(v) => {
                        actions.updateChapter(c.id, { understanding: v === "" ? null : (v as never) });
                        toast("Understanding updated");
                      }}
                      options={[{ value: "", label: "Update understanding…" }, ...UNDERSTANDINGS.map((u) => ({ value: u.value, label: u.label }))]}
                    />
                    {c.weakManual && (
                      <Button size="sm" variant="ghost" onClick={() => { actions.updateChapter(c.id, { weakManual: false }); toast("Manual weak flag removed"); }}>
                        Remove weak flag
                      </Button>
                    )}
                    {c.status === "needs_revision" && (
                      <Button size="sm" variant="ghost" onClick={() => { actions.setStatus(c.id, "completed"); toast("Marked completed again"); }}>
                        Revision done → Completed
                      </Button>
                    )}
                  </div>
                </Card>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
