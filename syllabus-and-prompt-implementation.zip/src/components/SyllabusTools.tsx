"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { parseSyllabusText } from "@/lib/utils";
import { useUI } from "./Dialogs";
import { Button, Field, Modal, Select } from "./ui";

export function ImportSyllabusDialog({ subjectId, onClose }: { subjectId?: string; onClose: () => void }) {
  const { data, actions } = useStore();
  const { toast } = useUI();
  const [sid, setSid] = useState(subjectId ?? data.subjects[0]?.id ?? "");
  const [text, setText] = useState("");
  const [replace, setReplace] = useState(false);
  const parsed = useMemo(() => parseSyllabusText(text), [text]);
  const existing = data.chapters.filter((c) => c.subjectId === sid).length;

  const run = () => {
    if (!sid) return toast("Choose a subject first", "error");
    if (parsed.length === 0) return toast("Paste at least one chapter line", "error");
    const added = actions.importChapters(sid, parsed, replace);
    toast(added ? `Imported ${added} chapter${added === 1 ? "" : "s"}` : "No new chapters — all names already exist", added ? "success" : "info");
    onClose();
  };

  return (
    <Modal
      open
      wide
      onClose={onClose}
      title="Import syllabus chapters"
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={run}>
            Import {parsed.length || ""} chapter{parsed.length === 1 ? "" : "s"}
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <Field label="Subject">
          <Select value={sid} onChange={setSid} options={data.subjects.map((s) => ({ value: s.id, label: s.name }))} />
        </Field>
        <Field
          label="Paste chapters from your syllabus PDF"
          hint="One chapter per line. Start a line with “Unit:” or “Section:” (or #) to group chapters. Indent a line, or start it with “-”, to add it as a subtopic of the chapter above. Numbering is removed automatically."
        >
          <textarea
            className="input !min-h-52 font-mono !text-[13px]"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={"Unit: <section name from the PDF>\n1. <Chapter name exactly as in the PDF>\n   - <subtopic>\n2. <Next chapter>"}
          />
        </Field>
        <label className="flex min-h-10 items-center gap-2 text-sm">
          <input type="checkbox" className="h-4 w-4 accent-[var(--accent)]" checked={replace} onChange={(e) => setReplace(e.target.checked)} />
          Replace the {existing} existing chapter{existing === 1 ? "" : "s"} in this subject (progress on them will be lost)
        </label>
        {parsed.length > 0 && (
          <div className="max-h-48 overflow-y-auto rounded-xl bg-surface2 p-3 text-[13px]">
            <p className="mb-1 font-medium">Preview ({parsed.length})</p>
            <ol className="list-decimal space-y-0.5 pl-5">
              {parsed.map((p, i) => (
                <li key={i}>
                  {p.name}
                  {p.unit && <span className="text-muted"> — {p.unit}</span>}
                  {p.subtopics.length > 0 && <span className="text-muted"> ({p.subtopics.length} subtopics)</span>}
                </li>
              ))}
            </ol>
          </div>
        )}
        <p className="text-xs text-muted">Duplicate chapter names within a subject are skipped. You can edit any chapter afterwards.</p>
      </div>
    </Modal>
  );
}

export function AddChapterDialog({ subjectId, onClose }: { subjectId?: string; onClose: () => void }) {
  const { data, actions } = useStore();
  const { toast, openChapter } = useUI();
  const [sid, setSid] = useState(subjectId ?? data.subjects[0]?.id ?? "");
  const [name, setName] = useState("");
  const [unit, setUnit] = useState("");
  const [err, setErr] = useState("");

  const save = () => {
    if (!name.trim()) return setErr("Enter a chapter name.");
    const dup = data.chapters.some((c) => c.subjectId === sid && c.name.trim().toLowerCase() === name.trim().toLowerCase());
    if (dup) return setErr("This subject already has a chapter with that name.");
    const id = actions.addChapter(sid, name.trim(), { unit: unit.trim() });
    toast("Chapter added");
    onClose();
    setTimeout(() => openChapter(id), 50);
  };

  return (
    <Modal
      open
      onClose={onClose}
      title="Add chapter"
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={save}>
            Add chapter
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        {err && (
          <p role="alert" className="rounded-xl bg-bad-soft px-3 py-2 text-[13px] text-bad">
            {err}
          </p>
        )}
        <Field label="Subject">
          <Select value={sid} onChange={setSid} options={data.subjects.map((s) => ({ value: s.id, label: s.name }))} />
        </Field>
        <Field label="Chapter name">
          <input className="input" autoFocus value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Unit / section (optional)">
          <input className="input" value={unit} onChange={(e) => setUnit(e.target.value)} />
        </Field>
      </div>
    </Modal>
  );
}
