"use client";

import Link from "next/link";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { STATUSES, UNDERSTANDINGS, type Chapter, type Subject } from "@/lib/types";
import { fmtDate, fmtDuration, latestPractice, practicePct, subjectStats, weakReasons } from "@/lib/utils";
import { useUI } from "./Dialogs";
import { Badge, Button, Card, PriorityBadge, ProgressBar, Select, StatusBadge, UnderstandingBadge, cx } from "./ui";

export function ChapterRow({ chapter, showSubject, expandable }: { chapter: Chapter; showSubject?: boolean; expandable?: boolean }) {
  const { data, actions } = useStore();
  const { openChapter, openRevision, openPractice, toast } = useUI();
  const [open, setOpen] = useState(false);
  const subject = data.subjects.find((s) => s.id === chapter.subjectId);
  const weak = weakReasons(chapter, data.practice);
  const lp = latestPractice(chapter.id, data.practice);
  const pendingRev = data.revisions.filter((r) => r.chapterId === chapter.id && !r.done).sort((a, b) => (a.date < b.date ? -1 : 1))[0];
  const nextRev = pendingRev?.date ?? chapter.nextRevision;

  const changeStatus = (s: Chapter["status"]) => {
    actions.setStatus(chapter.id, s);
    toast(s === "completed" ? `“${chapter.name}” marked completed 🎉` : `Status: ${STATUSES.find((x) => x.value === s)?.label}`);
  };

  return (
    <div className="rounded-xl border border-line bg-surface">
      <div className="flex flex-col gap-2.5 p-3 sm:flex-row sm:items-center sm:gap-3">
        <div className="flex min-w-0 flex-1 items-start gap-2">
          {expandable && (
            <button
              onClick={() => setOpen(!open)}
              aria-expanded={open}
              aria-label={open ? "Collapse chapter details" : "Expand chapter details"}
              className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg text-muted hover:bg-surface2"
            >
              <span className={cx("transition-transform", open && "rotate-90")}>▸</span>
            </button>
          )}
          <div className="min-w-0 flex-1">
            <button onClick={() => openChapter(chapter.id)} className="block max-w-full text-left text-[15px] font-medium leading-snug hover:text-accent">
              {chapter.name}
            </button>
            <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
              {showSubject && subject && <Badge tone="accent">{subject.name}</Badge>}
              <StatusBadge status={chapter.status} />
              <UnderstandingBadge value={chapter.understanding} />
              <PriorityBadge value={chapter.priority} />
              {weak.length > 0 && <Badge tone="bad">⚑ Weak</Badge>}
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2 pl-0 sm:pl-2">
          <Select
            aria-label={`Status for ${chapter.name}`}
            className="!min-h-10 flex-1 sm:w-40 sm:flex-none"
            value={chapter.status}
            onChange={(v) => changeStatus(v as Chapter["status"])}
            options={STATUSES.map((s) => ({ value: s.value, label: s.label }))}
          />
          <Select
            aria-label={`Understanding for ${chapter.name}`}
            className="!min-h-10 flex-1 sm:w-36 sm:flex-none"
            value={chapter.understanding ?? ""}
            onChange={(v) => {
              actions.updateChapter(chapter.id, { understanding: v === "" ? null : (v as Chapter["understanding"]) });
              toast("Understanding updated");
            }}
            options={[{ value: "", label: "Not rated" }, ...UNDERSTANDINGS.map((u) => ({ value: u.value, label: u.label }))]}
          />
        </div>
      </div>

      {open && (
        <div className="anim-fade space-y-3 border-t border-line px-3 py-3 text-[13px]">
          {chapter.unit && (
            <p>
              <span className="text-muted">Unit / section: </span>
              {chapter.unit}
            </p>
          )}
          {chapter.subtopics.length > 0 && (
            <div>
              <p className="mb-1 text-muted">Subtopics</p>
              <ul className="list-disc space-y-0.5 pl-5">
                {chapter.subtopics.map((t) => (
                  <li key={t}>{t}</li>
                ))}
              </ul>
            </div>
          )}
          <dl className="grid grid-cols-2 gap-x-4 gap-y-2 sm:grid-cols-4">
            <Info label="Last studied" value={fmtDate(chapter.lastStudied)} />
            <Info label="Next revision" value={fmtDate(nextRev)} />
            <Info label="Time studied" value={fmtDuration(chapter.actualMin)} />
            <Info label="Latest practice" value={lp ? `${practicePct(lp)}%` : "—"} />
          </dl>
          {chapter.notes && <p className="whitespace-pre-wrap rounded-lg bg-surface2 p-2.5">{chapter.notes}</p>}
          {weak.length > 0 && <p className="text-bad">Why weak: {weak.join(" · ")}</p>}
          <div className="flex flex-wrap gap-2">
            <Button size="sm" onClick={() => changeStatus("in_progress")} disabled={chapter.status === "in_progress"}>
              ▶ Start studying
            </Button>
            <Button size="sm" variant="primary" onClick={() => changeStatus("completed")} disabled={chapter.status === "completed"}>
              ✓ Mark completed
            </Button>
            <Button size="sm" onClick={() => openChapter(chapter.id)}>
              ✐ Add notes / edit
            </Button>
            <Button size="sm" onClick={() => openRevision({ subjectId: chapter.subjectId, chapterId: chapter.id })}>
              ↻ Schedule revision
            </Button>
            <Button size="sm" onClick={() => openPractice({ subjectId: chapter.subjectId, chapterId: chapter.id })}>
              ✎ Record test result
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="font-medium">{value}</dd>
    </div>
  );
}

export function SubjectCard({ subject }: { subject: Subject }) {
  const { data } = useStore();
  const st = subjectStats(subject.id, data.chapters);
  return (
    <Card className="flex flex-col gap-3 p-4">
      <div className="flex items-start justify-between gap-2">
        <h3 className="text-[15px] font-semibold leading-snug">{subject.name}</h3>
        <span className="text-xl font-semibold tabular-nums text-accent">{st.total ? `${st.percent}%` : "—"}</span>
      </div>
      <ProgressBar value={st.percent} label={`${subject.name} completion`} />
      {st.total === 0 ? (
        <p className="rounded-lg bg-warn-soft px-3 py-2 text-xs text-warn">No chapters imported yet — add the syllabus to start tracking.</p>
      ) : (
        <dl className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="rounded-lg bg-surface2 py-2">
            <dd className="text-base font-semibold">{st.total}</dd>
            <dt className="text-muted">Chapters</dt>
          </div>
          <div className="rounded-lg bg-surface2 py-2">
            <dd className="text-base font-semibold">{st.completed}</dd>
            <dt className="text-muted">Done</dt>
          </div>
          <div className="rounded-lg bg-surface2 py-2">
            <dd className="text-base font-semibold">{st.needsRevision}</dd>
            <dt className="text-muted">Revise</dt>
          </div>
        </dl>
      )}
      <Link
        href={`/subjects/${subject.id}`}
        className="mt-auto inline-flex min-h-10 items-center justify-center rounded-xl border border-line text-sm font-medium hover:bg-surface2"
      >
        Open subject →
      </Link>
    </Card>
  );
}
