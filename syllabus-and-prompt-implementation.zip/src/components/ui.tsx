"use client";

import { useEffect, useId, useRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import type { Priority, Status, Understanding } from "@/lib/types";
import { priorityLabel, statusLabel, understandingLabel } from "@/lib/utils";

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(" ");

/* ---------- Button ---------- */
type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md";
};
export function Button({ variant = "secondary", size = "md", className, type = "button", ...rest }: BtnProps) {
  const base =
    "inline-flex items-center justify-center gap-2 rounded-xl font-medium transition active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none whitespace-nowrap";
  const sizes = size === "sm" ? "min-h-9 px-3 text-[13px]" : "min-h-11 px-4 text-sm";
  const variants = {
    primary: "bg-accent text-accent-fg hover:opacity-90 shadow-sm",
    secondary: "bg-surface border border-line text-fg hover:bg-surface2",
    ghost: "text-muted hover:bg-surface2 hover:text-fg",
    danger: "bg-bad-soft text-bad border border-transparent hover:opacity-80",
  }[variant];
  return <button type={type} className={cx(base, sizes, variants, className)} {...rest} />;
}

/* ---------- Card ---------- */
export function Card({ className, children, ...rest }: { className?: string; children: ReactNode } & React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cx("rounded-2xl border border-line bg-surface shadow-card", className)} {...rest}>
      {children}
    </div>
  );
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between gap-3">
      <h2 className="text-[15px] font-semibold tracking-tight">{children}</h2>
      {action}
    </div>
  );
}

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div className="min-w-0">
        <h1 className="text-2xl font-semibold tracking-tight sm:text-[28px]">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-muted">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
    </div>
  );
}

/* ---------- Badges ---------- */
type Tone = "ok" | "warn" | "bad" | "info" | "neutral" | "accent";
const toneCls: Record<Tone, string> = {
  ok: "bg-ok-soft text-ok",
  warn: "bg-warn-soft text-warn",
  bad: "bg-bad-soft text-bad",
  info: "bg-info-soft text-info",
  neutral: "bg-neutral-soft text-muted",
  accent: "bg-accent-soft text-accent",
};
export function Badge({ tone = "neutral", children, className }: { tone?: Tone; children: ReactNode; className?: string }) {
  return (
    <span className={cx("inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium", toneCls[tone], className)}>
      {children}
    </span>
  );
}
const statusTone: Record<Status, Tone> = { not_started: "neutral", in_progress: "info", completed: "ok", needs_revision: "warn" };
const statusIcon: Record<Status, string> = { not_started: "○", in_progress: "◐", completed: "✓", needs_revision: "↻" };
export function StatusBadge({ status }: { status: Status }) {
  return (
    <Badge tone={statusTone[status]}>
      <span aria-hidden>{statusIcon[status]}</span>
      {statusLabel(status)}
    </Badge>
  );
}
export function UnderstandingBadge({ value }: { value: Understanding | null }) {
  const tone: Tone = !value ? "neutral" : value === "very_weak" ? "bad" : value === "weak" ? "warn" : value === "average" ? "info" : "ok";
  return <Badge tone={tone}>{understandingLabel(value)}</Badge>;
}
export function PriorityBadge({ value }: { value: Priority }) {
  return <Badge tone={value === "high" ? "bad" : value === "medium" ? "warn" : "neutral"}>{priorityLabel(value)}</Badge>;
}

/* ---------- Progress ---------- */
export function ProgressBar({ value, className, label }: { value: number; className?: string; label?: string }) {
  const v = Math.min(100, Math.max(0, Number.isFinite(value) ? value : 0));
  return (
    <div
      className={cx("h-2 w-full overflow-hidden rounded-full bg-surface2", className)}
      role="progressbar"
      aria-valuenow={v}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label ?? "Progress"}
    >
      <div className="h-full rounded-full bg-accent transition-all duration-500" style={{ width: `${v}%` }} />
    </div>
  );
}

export function Ring({ value, size = 96, stroke = 10, children }: { value: number; size?: number; stroke?: number; children?: ReactNode }) {
  const v = Math.min(100, Math.max(0, value));
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90" aria-hidden>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface2)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="var(--accent)"
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c - (v / 100) * c}
          style={{ transition: "stroke-dashoffset .6s ease" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-center">{children}</div>
    </div>
  );
}

/* ---------- Empty state ---------- */
export function EmptyState({ title, text, action }: { title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="rounded-xl border border-dashed border-line px-4 py-8 text-center">
      <p className="text-sm font-medium">{title}</p>
      {text && <p className="mx-auto mt-1 max-w-md text-[13px] text-muted">{text}</p>}
      {action && <div className="mt-3 flex justify-center">{action}</div>}
    </div>
  );
}

/* ---------- Form fields ---------- */
export function Field({ label, children, hint, className }: { label: string; children: ReactNode; hint?: string; className?: string }) {
  const id = useId();
  return (
    <div className={cx("block", className)}>
      <label htmlFor={id} className="mb-1 block text-[13px] font-medium text-muted">
        {label}
      </label>
      <FieldCtx id={id}>{children}</FieldCtx>
      {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
    </div>
  );
}
// Injects the id into the single child control
import { Children, cloneElement, isValidElement } from "react";
function FieldCtx({ id, children }: { id: string; children: ReactNode }) {
  const only = Children.only(children);
  if (isValidElement(only)) return cloneElement(only as React.ReactElement<{ id?: string }>, { id });
  return <>{children}</>;
}

export function Select({
  value,
  onChange,
  options,
  className,
  "aria-label": ariaLabel,
  id,
}: {
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  className?: string;
  "aria-label"?: string;
  id?: string;
}) {
  return (
    <select id={id} aria-label={ariaLabel} className={cx("input", className)} value={value} onChange={(e) => onChange(e.target.value)}>
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

/* ---------- Modal ---------- */
export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    ref.current?.focus();
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      prev?.focus?.();
    };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center sm:items-center sm:p-4">
      <div className="anim-fade absolute inset-0 bg-black/50" onClick={onClose} aria-hidden />
      <div
        ref={ref}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cx(
          "anim-pop relative flex max-h-[92dvh] w-full flex-col rounded-t-3xl border border-line bg-surface shadow-2xl outline-none sm:rounded-2xl",
          wide ? "sm:max-w-3xl" : "sm:max-w-xl",
        )}
      >
        <div className="flex items-center justify-between gap-3 border-b border-line px-5 py-4">
          <h2 className="truncate text-base font-semibold">{title}</h2>
          <button onClick={onClose} aria-label="Close dialog" className="grid h-9 w-9 place-items-center rounded-lg text-muted hover:bg-surface2">
            ✕
          </button>
        </div>
        <div className="overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="flex flex-wrap justify-end gap-2 border-t border-line px-5 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">{footer}</div>}
      </div>
    </div>
  );
}

/* ---------- Charts (dependency-free SVG/CSS) ---------- */
export function BarList({ items, unit = "", max }: { items: { label: string; value: number; sub?: string }[]; unit?: string; max?: number }) {
  const m = max ?? Math.max(1, ...items.map((i) => i.value));
  return (
    <ul className="space-y-3">
      {items.map((i) => (
        <li key={i.label}>
          <div className="mb-1 flex items-baseline justify-between gap-2 text-[13px]">
            <span className="truncate font-medium">{i.label}</span>
            <span className="shrink-0 text-muted">
              {i.sub ?? `${i.value}${unit}`}
            </span>
          </div>
          <ProgressBar value={(i.value / m) * 100} label={i.label} />
        </li>
      ))}
    </ul>
  );
}

export function ColumnChart({
  data,
  height = 140,
  format,
}: {
  data: { label: string; value: number; highlight?: boolean }[];
  height?: number;
  format?: (n: number) => string;
}) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="flex items-end gap-1.5" style={{ height: height + 36 }} role="img" aria-label="Column chart">
      {data.map((d, i) => (
        <div key={i} className="flex min-w-0 flex-1 flex-col items-center justify-end gap-1">
          <span className="text-[10px] text-muted">{d.value > 0 ? (format ? format(d.value) : d.value) : ""}</span>
          <div
            className={cx("w-full max-w-9 rounded-t-md transition-all duration-500", d.highlight ? "bg-accent" : "bg-accent/55")}
            style={{ height: Math.max(d.value > 0 ? 4 : 2, (d.value / max) * height) }}
          />
          <span className="w-full truncate text-center text-[10px] text-muted">{d.label}</span>
        </div>
      ))}
    </div>
  );
}

export function LineChart({ points, height = 150 }: { points: { label: string; value: number }[]; height?: number }) {
  const w = 600;
  const pad = 24;
  const n = points.length;
  const x = (i: number) => (n === 1 ? w / 2 : pad + (i * (w - pad * 2)) / (n - 1));
  const y = (v: number) => height - pad - (v / 100) * (height - pad * 2);
  const path = points.map((p, i) => `${i ? "L" : "M"}${x(i)},${y(p.value)}`).join(" ");
  return (
    <div>
      <svg viewBox={`0 0 ${w} ${height}`} className="w-full" role="img" aria-label="Score trend line chart">
        {[0, 50, 100].map((g) => (
          <g key={g}>
            <line x1={pad} x2={w - pad} y1={y(g)} y2={y(g)} stroke="var(--line)" strokeDasharray="4 4" />
            <text x={0} y={y(g) + 4} fontSize="10" fill="var(--muted)">
              {g}
            </text>
          </g>
        ))}
        {n > 1 && <path d={path} fill="none" stroke="var(--accent)" strokeWidth="2.5" strokeLinejoin="round" />}
        {points.map((p, i) => (
          <circle key={i} cx={x(i)} cy={y(p.value)} r="4" fill="var(--accent)">
            <title>{`${p.label}: ${p.value}%`}</title>
          </circle>
        ))}
      </svg>
      <div className="flex justify-between text-[10px] text-muted">
        <span>{points[0]?.label}</span>
        <span>{points[n - 1]?.label}</span>
      </div>
    </div>
  );
}

export function Donut({ parts, size = 130 }: { parts: { label: string; value: number; color: string }[]; size?: number }) {
  const total = parts.reduce((a, b) => a + b.value, 0);
  const r = 46;
  const c = 2 * Math.PI * r;
  let off = 0;
  return (
    <div className="flex flex-wrap items-center gap-5">
      <svg width={size} height={size} viewBox="0 0 120 120" role="img" aria-label="Status distribution">
        <circle cx="60" cy="60" r={r} fill="none" stroke="var(--surface2)" strokeWidth="16" />
        {total > 0 &&
          parts.map((p) => {
            const len = (p.value / total) * c;
            const el = (
              <circle
                key={p.label}
                cx="60"
                cy="60"
                r={r}
                fill="none"
                stroke={p.color}
                strokeWidth="16"
                strokeDasharray={`${len} ${c - len}`}
                strokeDashoffset={-off}
                transform="rotate(-90 60 60)"
              />
            );
            off += len;
            return el;
          })}
        <text x="60" y="64" textAnchor="middle" fontSize="20" fontWeight="600" fill="var(--fg)">
          {total}
        </text>
      </svg>
      <ul className="space-y-1.5 text-[13px]">
        {parts.map((p) => (
          <li key={p.label} className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: p.color }} />
            <span className="text-muted">{p.label}</span>
            <span className="font-medium">{p.value}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
