"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { StoreProvider, useStore } from "@/lib/store";
import { fmtClock, fmtShort } from "@/lib/utils";
import { UIProvider, useUI } from "./Dialogs";
import { cx } from "./ui";

const MAIN_NAV = [
  { href: "/", label: "Dashboard", icon: "◧" },
  { href: "/subjects", label: "My Subjects", icon: "▤" },
  { href: "/syllabus", label: "Syllabus Tracker", icon: "☑" },
  { href: "/planner", label: "Daily Planner", icon: "▦" },
  { href: "/revision", label: "Revision Planner", icon: "↻" },
  { href: "/practice", label: "Practice & Tests", icon: "✎" },
  { href: "/analytics", label: "Progress Analytics", icon: "◔" },
  { href: "/settings", label: "Settings", icon: "⚙" },
];
const MORE_NAV = [
  { href: "/weak", label: "Weak Chapters", icon: "⚑" },
  { href: "/calendar", label: "Calendar", icon: "▥" },
  { href: "/notes", label: "Notes", icon: "✐" },
  { href: "/timer", label: "Study Timer", icon: "◷" },
];
const BOTTOM = [
  { href: "/", label: "Home", icon: "◧" },
  { href: "/syllabus", label: "Syllabus", icon: "☑" },
  { href: "/planner", label: "Planner", icon: "▦" },
  { href: "/revision", label: "Revise", icon: "↻" },
];

export function Shell({ children }: { children: ReactNode }) {
  return (
    <StoreProvider>
      <UIProvider>
        <Frame>{children}</Frame>
      </UIProvider>
    </StoreProvider>
  );
}

function isActive(path: string, href: string) {
  return href === "/" ? path === "/" : path === href || path.startsWith(href + "/");
}

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  const path = usePathname();
  const item = (n: { href: string; label: string; icon: string }) => (
    <Link
      key={n.href}
      href={n.href}
      onClick={onNavigate}
      aria-current={isActive(path, n.href) ? "page" : undefined}
      className={cx(
        "flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-medium transition",
        isActive(path, n.href) ? "bg-accent-soft text-accent" : "text-muted hover:bg-surface2 hover:text-fg",
      )}
    >
      <span className="w-5 text-center text-base" aria-hidden>
        {n.icon}
      </span>
      {n.label}
    </Link>
  );
  return (
    <nav aria-label="Main" className="space-y-1">
      {MAIN_NAV.map(item)}
      <p className="px-3 pb-1 pt-4 text-[11px] font-semibold uppercase tracking-wider text-muted">More tools</p>
      {MORE_NAV.map(item)}
    </nav>
  );
}

function Brand() {
  return (
    <div className="flex items-center gap-3 px-2">
      <div className="grid h-9 w-9 place-items-center rounded-xl bg-accent text-sm font-bold text-accent-fg">27</div>
      <div className="leading-tight">
        <p className="text-sm font-semibold">HSLC 2027</p>
        <p className="text-xs text-muted">Exam Planner</p>
      </div>
    </div>
  );
}

function TimerPill() {
  const { data } = useStore();
  const t = data.timer;
  const [now, setNow] = useState(0);
  useEffect(() => {
    if (!t.active || t.runningSince == null) return;
    const i = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(i);
  }, [t.active, t.runningSince]);
  if (!t.active) return null;
  const n = now || (t.runningSince ?? 0);
  const total = t.studyMs + (t.runningSince != null && t.phase === "study" ? Math.max(0, n - t.runningSince) : 0);
  return (
    <Link href="/timer" className="hidden items-center gap-2 rounded-full bg-accent-soft px-3 py-1.5 text-xs font-semibold text-accent sm:flex">
      <span className={cx("h-2 w-2 rounded-full bg-accent", t.runningSince != null && "animate-pulse")} />
      {fmtClock(total)}
    </Link>
  );
}

function GlobalSearch() {
  const { data } = useStore();
  const { openChapter, setFocus } = useUI();
  const router = useRouter();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (!box.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (s.length < 2) return [];
    const subj = (id: string) => data.subjects.find((x) => x.id === id)?.name ?? "";
    const chap = (id: string | null) => data.chapters.find((x) => x.id === id)?.name ?? "";
    const out: { key: string; kind: string; title: string; sub: string; go: () => void }[] = [];
    data.subjects.forEach((x) => x.name.toLowerCase().includes(s) && out.push({ key: "s" + x.id, kind: "Subject", title: x.name, sub: "Open subject page", go: () => router.push(`/subjects/${x.id}`) }));
    data.chapters.forEach(
      (x) =>
        (x.name.toLowerCase().includes(s) || x.unit.toLowerCase().includes(s) || x.subtopics.some((t) => t.toLowerCase().includes(s))) &&
        out.push({ key: "c" + x.id, kind: "Chapter", title: x.name, sub: subj(x.subjectId), go: () => openChapter(x.id) }),
    );
    data.notes.forEach(
      (x) =>
        (x.title.toLowerCase().includes(s) || x.content.toLowerCase().includes(s)) &&
        out.push({ key: "n" + x.id, kind: "Note", title: x.title || "Untitled", sub: subj(x.subjectId ?? "") || "General", go: () => { setFocus({ noteId: x.id }); router.push("/notes"); } }),
    );
    data.tasks.forEach(
      (x) =>
        (x.description.toLowerCase().includes(s) || x.type.toLowerCase().includes(s) || chap(x.chapterId).toLowerCase().includes(s)) &&
        out.push({ key: "t" + x.id, kind: "Task", title: x.description || x.type, sub: `${fmtShort(x.date)} · ${subj(x.subjectId)}`, go: () => { setFocus({ date: x.date }); router.push("/planner"); } }),
    );
    data.revisions.forEach(
      (x) =>
        (chap(x.chapterId).toLowerCase().includes(s) || x.type.toLowerCase().includes(s) || x.notes.toLowerCase().includes(s)) &&
        out.push({ key: "r" + x.id, kind: "Revision", title: `${x.type}: ${chap(x.chapterId)}`, sub: fmtShort(x.date), go: () => router.push("/revision") }),
    );
    return out.slice(0, 12);
  }, [q, data, router, openChapter, setFocus]);

  return (
    <div ref={box} className="relative min-w-0 flex-1 sm:max-w-md">
      <input
        type="search"
        aria-label="Search subjects, chapters, notes, tasks and revisions"
        placeholder="Search chapters, notes, tasks…"
        value={q}
        onChange={(e) => {
          setQ(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={(e) => e.key === "Escape" && setOpen(false)}
        className="input !min-h-10 !rounded-full !bg-surface2 !pl-4"
      />
      {open && q.trim().length >= 2 && (
        <div className="anim-pop absolute left-0 right-0 top-12 z-50 max-h-[70dvh] overflow-y-auto rounded-2xl border border-line bg-surface p-1.5 shadow-2xl">
          {results.length === 0 ? (
            <p className="px-3 py-4 text-center text-sm text-muted">No matches for “{q}”.</p>
          ) : (
            results.map((r) => (
              <button
                key={r.key}
                onClick={() => {
                  r.go();
                  setOpen(false);
                  setQ("");
                }}
                className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left hover:bg-surface2"
              >
                <span className="w-16 shrink-0 text-[11px] font-semibold uppercase tracking-wide text-accent">{r.kind}</span>
                <span className="min-w-0">
                  <span className="block truncate text-sm font-medium">{r.title}</span>
                  <span className="block truncate text-xs text-muted">{r.sub}</span>
                </span>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}

function Frame({ children }: { children: ReactNode }) {
  const { data, ready, actions, saveError } = useStore();
  const { openTask } = useUI();
  const path = usePathname();
  const [drawer, setDrawer] = useState(false);
  const dark = data.settings.theme === "dark";

  useEffect(() => {
    if (!drawer) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && setDrawer(false);
    document.addEventListener("keydown", h);
    return () => document.removeEventListener("keydown", h);
  }, [drawer]);

  return (
    <div className="min-h-dvh">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col gap-5 overflow-y-auto border-r border-line bg-surface px-3 py-5 lg:flex">
        <Brand />
        <NavList />
        <p className="mt-auto px-3 text-[11px] leading-snug text-muted">Data is saved in this browser only. Use Settings → Export for backups.</p>
      </aside>

      {drawer && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="anim-fade absolute inset-0 bg-black/50" onClick={() => setDrawer(false)} aria-hidden />
          <div className="anim-slide absolute inset-y-0 left-0 flex w-72 max-w-[85vw] flex-col gap-4 overflow-y-auto bg-surface px-3 py-5" role="dialog" aria-label="Navigation menu">
            <div className="flex items-center justify-between">
              <Brand />
              <button onClick={() => setDrawer(false)} aria-label="Close menu" className="grid h-10 w-10 place-items-center rounded-lg text-muted hover:bg-surface2">
                ✕
              </button>
            </div>
            <NavList onNavigate={() => setDrawer(false)} />
          </div>
        </div>
      )}

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-line bg-bg/85 px-3 py-2.5 backdrop-blur sm:gap-3 sm:px-6">
          <button onClick={() => setDrawer(true)} aria-label="Open menu" className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-line bg-surface text-lg lg:hidden">
            ☰
          </button>
          <GlobalSearch />
          <div className="ml-auto flex shrink-0 items-center gap-2">
            <TimerPill />
            <button
              onClick={() => openTask({})}
              className="hidden min-h-10 items-center gap-1.5 rounded-xl bg-accent px-3.5 text-sm font-medium text-accent-fg hover:opacity-90 md:inline-flex"
            >
              ＋ Study session
            </button>
            <button
              onClick={() => actions.updateSettings({ theme: dark ? "light" : "dark" })}
              aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
              title={dark ? "Light mode" : "Dark mode"}
              className="grid h-10 w-10 place-items-center rounded-xl border border-line bg-surface text-base hover:bg-surface2"
            >
              {dark ? "☀" : "☾"}
            </button>
          </div>
        </header>

        {saveError && (
          <div role="alert" className="mx-3 mt-3 rounded-xl bg-bad-soft px-4 py-2.5 text-sm text-bad sm:mx-6">
            {saveError}
          </div>
        )}

        <main className="mx-auto w-full max-w-6xl px-3 pb-28 pt-5 sm:px-6 lg:pb-10 lg:pt-7">
          {ready ? (
            <div key={path} className="anim-fade">
              {children}
            </div>
          ) : (
            <div className="grid min-h-[50dvh] place-items-center text-sm text-muted" role="status">
              Loading your planner…
            </div>
          )}
        </main>
      </div>

      <nav aria-label="Quick navigation" className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line bg-surface pb-[env(safe-area-inset-bottom)] lg:hidden">
        {BOTTOM.map((n) => (
          <Link
            key={n.href}
            href={n.href}
            aria-current={isActive(path, n.href) ? "page" : undefined}
            className={cx("flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium", isActive(path, n.href) ? "text-accent" : "text-muted")}
          >
            <span className="text-lg leading-none" aria-hidden>
              {n.icon}
            </span>
            {n.label}
          </Link>
        ))}
        <button onClick={() => setDrawer(true)} className="flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] font-medium text-muted">
          <span className="text-lg leading-none" aria-hidden>
            ≡
          </span>
          More
        </button>
      </nav>
    </div>
  );
}
