"use client";

import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import { useStore } from "@/lib/store";
import {
  PRACTICE_TYPES,
  PRIORITIES,
  REVISION_TYPES,
  STATUSES,
  TASK_TYPES,
  UNDERSTANDINGS,
  type CalEvent,
  type Chapter,
  type Practice,
  type Priority,
  type Revision,
  type Task,
} from "@/lib/types";
import { addDays, fmtDate, fmtDuration, practicePct, statusLabel, toNum, todayStr } from "@/lib/utils";
import { Badge, Button, Field, Modal, Select, StatusBadge, cx } from "./ui";

/* ===================== UI context ===================== */
type ToastKind = "success" | "error" | "info";
interface ToastItem {
  id: number;
  kind: ToastKind;
  text: string;
}
interface ConfirmState {
  title: string;
  text: string;
  confirmLabel?: string;
  onYes: () => void;
}
interface UICtx {
  toast: (text: string, kind?: ToastKind) => void;
  openTask: (def?: Partial<Task>) => void;
  openRevision: (def?: Partial<Revision>) => void;
  openPractice: (def?: Partial<Practice>) => void;
  openEvent: (def?: Partial<CalEvent>) => void;
  openChapter: (id: string) => void;
  confirm: (c: ConfirmState) => void;
  focus: { noteId?: string; date?: string };
  setFocus: (f: { noteId?: string; date?: string }) => void;
}
const Ctx = createContext<UICtx | null>(null);
export const useUI = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("useUI outside provider");
  return c;
};

export function UIProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [task, setTask] = useState<Partial<Task> | null>(null);
  const [rev, setRev] = useState<Partial<Revision> | null>(null);
  const [prac, setPrac] = useState<Partial<Practice> | null>(null);
  const [ev, setEv] = useState<Partial<CalEvent> | null>(null);
  const [chapterId, setChapterId] = useState<string | null>(null);
  const [conf, setConf] = useState<ConfirmState | null>(null);
  const [focus, setFocus] = useState<{ noteId?: string; date?: string }>({});

  const toast = useCallback((text: string, kind: ToastKind = "success") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, kind, text }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), kind === "error" ? 6000 : 3200);
  }, []);

  const value = useMemo<UICtx>(
    () => ({
      toast,
      openTask: (d = {}) => setTask(d),
      openRevision: (d = {}) => setRev(d),
      openPractice: (d = {}) => setPrac(d),
      openEvent: (d = {}) => setEv(d),
      openChapter: (id) => setChapterId(id),
      confirm: (c) => setConf(c),
      focus,
      setFocus,
    }),
    [toast, focus],
  );

  return (
    <Ctx.Provider value={value}>
      {children}
      {task && <TaskDialog def={task} onClose={() => setTask(null)} />}
      {rev && <RevisionDialog def={rev} onClose={() => setRev(null)} />}
      {prac && <PracticeDialog def={prac} onClose={() => setPrac(null)} />}
      {ev && <EventDialog def={ev} onClose={() => setEv(null)} />}
      {chapterId && <ChapterDialog id={chapterId} onClose={() => setChapterId(null)} />}
      {conf && (
        <Modal
          open
          onClose={() => setConf(null)}
          title={conf.title}
          footer={
            <>
              <Button onClick={() => setConf(null)}>Cancel</Button>
              <Button
                variant="danger"
                onClick={() => {
                  conf.onYes();
                  setConf(null);
                }}
              >
                {conf.confirmLabel ?? "Confirm"}
              </Button>
            </>
          }
        >
          <p className="text-sm text-muted">{conf.text}</p>
        </Modal>
      )}
      <div aria-live="polite" className="pointer-events-none fixed inset-x-0 bottom-20 z-[80] flex flex-col items-center gap-2 px-4 lg:bottom-6">
        {toasts.map((t) => (
          <div
            key={t.id}
            role={t.kind === "error" ? "alert" : "status"}
            className={cx(
              "anim-pop pointer-events-auto max-w-md rounded-xl px-4 py-2.5 text-sm font-medium shadow-lg",
              t.kind === "success" && "bg-fg text-bg",
              t.kind === "error" && "bg-bad text-white dark:text-black",
              t.kind === "info" && "bg-accent text-accent-fg",
            )}
          >
            {t.kind === "success" ? "✓ " : t.kind === "error" ? "⚠ " : ""}
            {t.text}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

/* ===================== shared bits ===================== */
function ErrorBox({ errors }: { errors: string[] }) {
  if (!errors.length) return null;
  return (
    <div role="alert" className="mb-3 rounded-xl bg-bad-soft px-3 py-2 text-[13px] text-bad">
      <ul className="list-disc pl-4">
        {errors.map((e) => (
          <li key={e}>{e}</li>
        ))}
      </ul>
    </div>
  );
}

export function SubjectChapterFields({
  subjectId,
  chapterId,
  onChange,
  chapterRequired,
}: {
  subjectId: string;
  chapterId: string | null;
  onChange: (s: string, c: string | null) => void;
  chapterRequired?: boolean;
}) {
  const { data } = useStore();
  const chapters = data.chapters.filter((c) => c.subjectId === subjectId).sort((a, b) => a.order - b.order);
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <Field label="Subject">
        <Select
          value={subjectId}
          onChange={(v) => onChange(v, null)}
          options={[{ value: "", label: "Select subject…" }, ...data.subjects.map((s) => ({ value: s.id, label: s.name }))]}
        />
      </Field>
      <Field label={chapterRequired ? "Chapter" : "Chapter (optional)"}>
        <Select
          value={chapterId ?? ""}
          onChange={(v) => onChange(subjectId, v || null)}
          options={[
            { value: "", label: !subjectId ? "Pick a subject first" : chapters.length ? (chapterRequired ? "Select chapter…" : "No specific chapter") : "No chapters yet" },
            ...chapters.map((c) => ({ value: c.id, label: c.name })),
          ]}
        />
      </Field>
    </div>
  );
}

const optNum = (n: number | null | undefined) => (n == null ? "" : String(n));

/* ===================== Task ===================== */
function TaskDialog({ def, onClose }: { def: Partial<Task>; onClose: () => void }) {
  const { actions } = useStore();
  const { toast } = useUI();
  const [f, setF] = useState({
    date: def.date ?? todayStr(),
    start: def.start ?? "",
    duration: String(def.durationMin ?? 45),
    subjectId: def.subjectId ?? "",
    chapterId: def.chapterId ?? null,
    type: def.type ?? TASK_TYPES[0],
    description: def.description ?? "",
    priority: (def.priority ?? "medium") as Priority,
    notes: def.notes ?? "",
    done: def.done ?? false,
    actual: optNum(def.actualMin),
  });
  const [errors, setErrors] = useState<string[]>([]);
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((x) => ({ ...x, [k]: v }));

  const save = () => {
    const e: string[] = [];
    const dur = toNum(f.duration);
    if (!f.date) e.push("Choose a date.");
    if (!f.subjectId) e.push("Choose a subject.");
    if (dur == null || dur <= 0 || dur > 1440) e.push("Duration must be between 1 and 1440 minutes.");
    setErrors(e);
    if (e.length) return;
    actions.saveTask({
      id: def.id,
      date: f.date,
      start: f.start,
      durationMin: Math.round(dur as number),
      subjectId: f.subjectId,
      chapterId: f.chapterId,
      type: f.type,
      description: f.description.trim(),
      priority: f.priority,
      done: f.done,
      actualMin: f.done ? Math.max(0, Math.round(toNum(f.actual) ?? (dur as number))) : null,
      notes: f.notes,
    });
    toast(def.id ? "Study session updated" : "Study session added");
    onClose();
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={def.id ? "Edit study session" : "Add study session"}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={save}>
            Save session
          </Button>
        </>
      }
    >
      <ErrorBox errors={errors} />
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <Field label="Date">
            <input type="date" className="input" value={f.date} onChange={(e) => set("date", e.target.value)} />
          </Field>
          <Field label="Start time (optional)">
            <input type="time" className="input" value={f.start} onChange={(e) => set("start", e.target.value)} />
          </Field>
          <Field label="Duration (min)" className="col-span-2 sm:col-span-1">
            <input type="number" min={1} inputMode="numeric" className="input" value={f.duration} onChange={(e) => set("duration", e.target.value)} />
          </Field>
        </div>
        <SubjectChapterFields subjectId={f.subjectId} chapterId={f.chapterId} onChange={(s, c) => setF((x) => ({ ...x, subjectId: s, chapterId: c }))} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Task type">
            <Select value={f.type} onChange={(v) => set("type", v)} options={TASK_TYPES.map((t) => ({ value: t, label: t }))} />
          </Field>
          <Field label="Priority">
            <Select value={f.priority} onChange={(v) => set("priority", v as Priority)} options={PRIORITIES.map((p) => ({ value: p.value, label: p.label }))} />
          </Field>
        </div>
        <Field label="Task description">
          <input className="input" value={f.description} onChange={(e) => set("description", e.target.value)} placeholder="e.g. Solve exercise 3.2 questions 1–6" />
        </Field>
        <Field label="Personal notes">
          <textarea className="input" value={f.notes} onChange={(e) => set("notes", e.target.value)} />
        </Field>
        <label className="flex min-h-10 items-center gap-2 text-sm">
          <input type="checkbox" className="h-4 w-4 accent-[var(--accent)]" checked={f.done} onChange={(e) => set("done", e.target.checked)} />
          Mark as completed
        </label>
        {f.done && (
          <Field label="Actual time studied (min)" hint="Leave blank to use the planned duration.">
            <input type="number" min={0} inputMode="numeric" className="input" value={f.actual} onChange={(e) => set("actual", e.target.value)} />
          </Field>
        )}
      </div>
    </Modal>
  );
}

/* ===================== Revision ===================== */
function RevisionDialog({ def, onClose }: { def: Partial<Revision>; onClose: () => void }) {
  const { data, actions } = useStore();
  const { toast } = useUI();
  const [f, setF] = useState({
    subjectId: def.subjectId ?? "",
    chapterId: (def.chapterId ?? null) as string | null,
    date: def.date ?? addDays(todayStr(), 1),
    type: def.type ?? REVISION_TYPES[0],
    difficulty: def.difficulty != null ? String(def.difficulty) : "",
    notes: def.notes ?? "",
  });
  const [errors, setErrors] = useState<string[]>([]);
  const { suggest, intervals } = data.settings.revision;

  const save = () => {
    const e: string[] = [];
    if (!f.subjectId) e.push("Choose a subject.");
    if (!f.chapterId) e.push("Choose a chapter to revise.");
    if (!f.date) e.push("Choose a date.");
    setErrors(e);
    if (e.length) return;
    actions.saveRevision({
      id: def.id,
      subjectId: f.subjectId,
      chapterId: f.chapterId as string,
      date: f.date,
      type: f.type,
      done: def.done ?? false,
      completedOn: def.completedOn ?? null,
      difficulty: f.difficulty ? Number(f.difficulty) : null,
      notes: f.notes,
    });
    toast(def.id ? "Revision updated" : "Revision scheduled");
    onClose();
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={def.id ? "Edit revision" : "Schedule revision"}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={save}>
            Save revision
          </Button>
        </>
      }
    >
      <ErrorBox errors={errors} />
      <div className="space-y-3">
        <SubjectChapterFields chapterRequired subjectId={f.subjectId} chapterId={f.chapterId} onChange={(s, c) => setF((x) => ({ ...x, subjectId: s, chapterId: c }))} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Scheduled date">
            <input type="date" className="input" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} />
          </Field>
          <Field label="Revision type">
            <Select value={f.type} onChange={(v) => setF({ ...f, type: v })} options={REVISION_TYPES.map((t) => ({ value: t, label: t }))} />
          </Field>
        </div>
        {suggest && intervals.length > 0 && (
          <div>
            <p className="mb-1 text-xs text-muted">Optional suggested intervals from today (customise in Settings):</p>
            <div className="flex flex-wrap gap-2">
              {intervals.map((n) => (
                <Button key={n} size="sm" onClick={() => setF({ ...f, date: addDays(todayStr(), n) })}>
                  +{n} day{n === 1 ? "" : "s"}
                </Button>
              ))}
            </div>
          </div>
        )}
        <Field label="Difficulty rating (optional)">
          <Select
            value={f.difficulty}
            onChange={(v) => setF({ ...f, difficulty: v })}
            options={[
              { value: "", label: "Not rated" },
              { value: "1", label: "1 – Very easy" },
              { value: "2", label: "2 – Easy" },
              { value: "3", label: "3 – Medium" },
              { value: "4", label: "4 – Hard" },
              { value: "5", label: "5 – Very hard" },
            ]}
          />
        </Field>
        <Field label="Notes">
          <textarea className="input" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
        </Field>
      </div>
    </Modal>
  );
}

/* ===================== Practice ===================== */
function PracticeDialog({ def, onClose }: { def: Partial<Practice>; onClose: () => void }) {
  const { actions } = useStore();
  const { toast } = useUI();
  const [f, setF] = useState({
    subjectId: def.subjectId ?? "",
    chapterId: (def.chapterId ?? null) as string | null,
    type: def.type ?? PRACTICE_TYPES[0],
    date: def.date ?? todayStr(),
    total: optNum(def.total),
    correct: optNum(def.correct),
    incorrect: optNum(def.incorrect),
    marks: optNum(def.marks),
    totalMarks: optNum(def.totalMarks),
    timeMin: optNum(def.timeMin),
    mistakes: def.mistakes ?? "",
    notes: def.notes ?? "",
  });
  const [errors, setErrors] = useState<string[]>([]);
  const p = { total: toNum(f.total), correct: toNum(f.correct), marks: toNum(f.marks), totalMarks: toNum(f.totalMarks) };
  const live = practicePct(p);

  const save = () => {
    const e: string[] = [];
    const n = { total: toNum(f.total), correct: toNum(f.correct), incorrect: toNum(f.incorrect), marks: toNum(f.marks), totalMarks: toNum(f.totalMarks), timeMin: toNum(f.timeMin) };
    if (!f.subjectId) e.push("Choose a subject.");
    if (!f.date) e.push("Choose a date.");
    for (const [k, v] of Object.entries(n)) if (v != null && v < 0) e.push(`${k} cannot be negative.`);
    if (n.total != null && n.correct != null && n.correct > n.total) e.push("Correct answers cannot exceed total questions.");
    if (n.total != null && n.incorrect != null && n.incorrect > n.total) e.push("Incorrect answers cannot exceed total questions.");
    if (n.total != null && n.correct != null && n.incorrect != null && n.correct + n.incorrect > n.total) e.push("Correct + incorrect cannot exceed total questions.");
    if (n.marks != null && n.totalMarks != null && n.marks > n.totalMarks) e.push("Marks obtained cannot exceed total marks.");
    if (n.marks != null && n.totalMarks == null) e.push("Enter total marks along with marks obtained.");
    if (n.totalMarks === 0) e.push("Total marks must be greater than zero (or leave it blank).");
    setErrors([...new Set(e)]);
    if (e.length) return;
    actions.savePractice({
      id: def.id,
      subjectId: f.subjectId,
      chapterId: f.chapterId,
      type: f.type,
      date: f.date,
      ...n,
      mistakes: f.mistakes,
      notes: f.notes,
    });
    toast(def.id ? "Practice record updated" : "Practice record saved");
    onClose();
  };

  const num = (k: "total" | "correct" | "incorrect" | "marks" | "totalMarks" | "timeMin", label: string) => (
    <Field label={label}>
      <input type="number" min={0} step="any" inputMode="decimal" className="input" value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
    </Field>
  );

  return (
    <Modal
      open
      onClose={onClose}
      title={def.id ? "Edit practice record" : "Record practice / test"}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={save}>
            Save record
          </Button>
        </>
      }
    >
      <ErrorBox errors={errors} />
      <div className="space-y-3">
        <SubjectChapterFields subjectId={f.subjectId} chapterId={f.chapterId} onChange={(s, c) => setF((x) => ({ ...x, subjectId: s, chapterId: c }))} />
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Practice type">
            <Select value={f.type} onChange={(v) => setF({ ...f, type: v })} options={PRACTICE_TYPES.map((t) => ({ value: t, label: t }))} />
          </Field>
          <Field label="Date">
            <input type="date" className="input" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} />
          </Field>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {num("total", "Total questions")}
          {num("correct", "Correct")}
          {num("incorrect", "Incorrect")}
        </div>
        <div className="grid grid-cols-3 gap-3">
          {num("marks", "Marks obtained")}
          {num("totalMarks", "Total marks")}
          {num("timeMin", "Time (min)")}
        </div>
        <p className="rounded-lg bg-surface2 px-3 py-2 text-[13px] text-muted">
          {live != null ? (
            <>
              Calculated score: <strong className="text-fg">{live}%</strong>
            </>
          ) : (
            "All score fields are optional — you can log a session without a number."
          )}
        </p>
        <Field label="Mistakes / difficult questions">
          <textarea className="input" value={f.mistakes} onChange={(e) => setF({ ...f, mistakes: e.target.value })} />
        </Field>
        <Field label="Personal notes">
          <textarea className="input" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
        </Field>
      </div>
    </Modal>
  );
}

/* ===================== Event ===================== */
function EventDialog({ def, onClose }: { def: Partial<CalEvent>; onClose: () => void }) {
  const { actions } = useStore();
  const { toast } = useUI();
  const [f, setF] = useState({
    date: def.date ?? todayStr(),
    title: def.title ?? "",
    kind: (def.kind ?? "deadline") as CalEvent["kind"],
    notes: def.notes ?? "",
  });
  const [errors, setErrors] = useState<string[]>([]);
  const save = () => {
    const e: string[] = [];
    if (!f.title.trim()) e.push("Enter a title.");
    if (!f.date) e.push("Choose a date.");
    setErrors(e);
    if (e.length) return;
    actions.saveEvent({ id: def.id, date: f.date, title: f.title.trim(), kind: f.kind, notes: f.notes, done: def.done ?? false });
    toast(def.id ? "Event updated" : "Event added");
    onClose();
  };
  return (
    <Modal
      open
      onClose={onClose}
      title={def.id ? "Edit date / deadline" : "Add date / deadline"}
      footer={
        <>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={save}>
            Save
          </Button>
        </>
      }
    >
      <ErrorBox errors={errors} />
      <div className="space-y-3">
        <Field label="Title">
          <input className="input" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="e.g. Finish Science syllabus" />
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Date">
            <input type="date" className="input" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} />
          </Field>
          <Field label="Type">
            <Select
              value={f.kind}
              onChange={(v) => setF({ ...f, kind: v as CalEvent["kind"] })}
              options={[
                { value: "deadline", label: "Personal deadline" },
                { value: "mock", label: "Mock test" },
                { value: "important", label: "Important date" },
              ]}
            />
          </Field>
        </div>
        <Field label="Notes">
          <textarea className="input" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
        </Field>
        <p className="text-xs text-muted">Only add official dates here once they are announced — nothing is pre-filled.</p>
      </div>
    </Modal>
  );
}

/* ===================== Chapter detail ===================== */
function ChapterDialog({ id, onClose }: { id: string; onClose: () => void }) {
  const { data, actions } = useStore();
  const { toast, openRevision, openPractice, openTask, confirm } = useUI();
  const chapter = data.chapters.find((c) => c.id === id);
  if (!chapter) return null;
  return (
    <ChapterForm
      chapter={chapter}
      onClose={onClose}
      onSave={(patch) => {
        actions.updateChapter(id, patch);
        toast("Chapter saved");
        onClose();
      }}
      onDelete={() =>
        confirm({
          title: "Delete this chapter?",
          text: "Its scheduled revisions will be removed. Practice records, notes and time logs are kept but unlinked from the chapter.",
          confirmLabel: "Delete chapter",
          onYes: () => {
            actions.deleteChapter(id);
            toast("Chapter deleted");
            onClose();
          },
        })
      }
      onSchedule={() => openRevision({ subjectId: chapter.subjectId, chapterId: chapter.id })}
      onPractice={() => openPractice({ subjectId: chapter.subjectId, chapterId: chapter.id })}
      onPlan={() => openTask({ subjectId: chapter.subjectId, chapterId: chapter.id })}
    />
  );
}

function ChapterForm({
  chapter,
  onClose,
  onSave,
  onDelete,
  onSchedule,
  onPractice,
  onPlan,
}: {
  chapter: Chapter;
  onClose: () => void;
  onSave: (patch: Partial<Chapter>) => void;
  onDelete: () => void;
  onSchedule: () => void;
  onPractice: () => void;
  onPlan: () => void;
}) {
  const { data } = useStore();
  const { toast } = useUI();
  const subject = data.subjects.find((s) => s.id === chapter.subjectId);
  const [f, setF] = useState({
    name: chapter.name,
    subjectId: chapter.subjectId,
    unit: chapter.unit,
    subtopics: chapter.subtopics.join("\n"),
    status: chapter.status,
    understanding: chapter.understanding ?? "",
    priority: chapter.priority,
    weakManual: chapter.weakManual,
    notes: chapter.notes,
    remarks: chapter.remarks,
    lastStudied: chapter.lastStudied ?? "",
    nextRevision: chapter.nextRevision ?? "",
    est: optNum(chapter.estRemainingMin),
    actual: String(chapter.actualMin),
    components: chapter.components,
    attempted: String(chapter.math.attempted),
    correct: String(chapter.math.correct),
    difficult: String(chapter.math.difficult),
    needsPractice: chapter.math.needsPractice,
  });
  const [errors, setErrors] = useState<string[]>([]);
  const [addMin, setAddMin] = useState("");

  const save = () => {
    const e: string[] = [];
    if (!f.name.trim()) e.push("Chapter name cannot be empty.");
    const est = toNum(f.est);
    const actual = toNum(f.actual);
    const att = toNum(f.attempted) ?? 0;
    const cor = toNum(f.correct) ?? 0;
    const dif = toNum(f.difficult) ?? 0;
    if (est != null && est < 0) e.push("Estimated time cannot be negative.");
    if (actual != null && actual < 0) e.push("Actual time cannot be negative.");
    if (cor > att) e.push("Questions answered correctly cannot exceed questions attempted.");
    if (att < 0 || cor < 0 || dif < 0) e.push("Practice counts cannot be negative.");
    setErrors(e);
    if (e.length) return;
    const statusChanged = f.status !== chapter.status;
    onSave({
      name: f.name.trim(),
      subjectId: f.subjectId,
      unit: f.unit.trim(),
      subtopics: f.subtopics.split("\n").map((s) => s.trim()).filter(Boolean),
      status: f.status,
      understanding: f.understanding === "" ? null : (f.understanding as Chapter["understanding"]),
      priority: f.priority,
      weakManual: f.weakManual,
      notes: f.notes,
      remarks: f.remarks,
      lastStudied: f.lastStudied || null,
      nextRevision: f.nextRevision || null,
      estRemainingMin: est,
      actualMin: Math.round(actual ?? 0),
      components: f.components,
      math: { attempted: att, correct: cor, difficult: dif, needsPractice: f.needsPractice },
      history: statusChanged ? [...chapter.history, { date: new Date().toISOString(), status: f.status }] : chapter.history,
    });
  };

  const revs = data.revisions.filter((r) => r.chapterId === chapter.id).sort((a, b) => (a.date < b.date ? -1 : 1));
  const prs = data.practice.filter((p) => p.chapterId === chapter.id).sort((a, b) => (a.date < b.date ? 1 : -1));
  const kind = subject?.kind;

  return (
    <Modal
      open
      wide
      onClose={onClose}
      title={chapter.name}
      footer={
        <>
          <Button variant="danger" onClick={onDelete} className="mr-auto">
            Delete
          </Button>
          <Button onClick={onClose}>Cancel</Button>
          <Button variant="primary" onClick={save}>
            Save changes
          </Button>
        </>
      }
    >
      <ErrorBox errors={errors} />
      <div className="space-y-5">
        <div className="flex flex-wrap gap-2">
          <Button size="sm" onClick={onPlan}>＋ Plan study session</Button>
          <Button size="sm" onClick={onSchedule}>↻ Schedule revision</Button>
          <Button size="sm" onClick={onPractice}>✎ Add practice / test</Button>
        </div>

        <section className="space-y-3">
          <h3 className="text-sm font-semibold">Details {chapter.imported && <Badge tone="accent" className="ml-1">Imported</Badge>}</h3>
          <Field label="Chapter name">
            <input className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          </Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Subject">
              <Select value={f.subjectId} onChange={(v) => setF({ ...f, subjectId: v })} options={data.subjects.map((s) => ({ value: s.id, label: s.name }))} />
            </Field>
            <Field label="Unit / section (if any)">
              <input className="input" value={f.unit} onChange={(e) => setF({ ...f, unit: e.target.value })} />
            </Field>
          </div>
          <Field label="Subtopics (one per line)">
            <textarea className="input" value={f.subtopics} onChange={(e) => setF({ ...f, subtopics: e.target.value })} />
          </Field>
        </section>

        <section className="space-y-3">
          <h3 className="text-sm font-semibold">Progress</h3>
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="Status">
              <Select value={f.status} onChange={(v) => setF({ ...f, status: v as Chapter["status"] })} options={STATUSES.map((s) => ({ value: s.value, label: s.label }))} />
            </Field>
            <Field label="Understanding">
              <Select value={f.understanding} onChange={(v) => setF({ ...f, understanding: v as never })} options={[{ value: "", label: "Not rated" }, ...UNDERSTANDINGS.map((u) => ({ value: u.value, label: u.label }))]} />
            </Field>
            <Field label="Priority">
              <Select value={f.priority} onChange={(v) => setF({ ...f, priority: v as Priority })} options={PRIORITIES.map((p) => ({ value: p.value, label: p.label }))} />
            </Field>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Last studied">
              <input type="date" className="input" value={f.lastStudied} onChange={(e) => setF({ ...f, lastStudied: e.target.value })} />
            </Field>
            <Field label="Next revision date" hint={revs.some((r) => !r.done) ? "A scheduled revision exists — see below." : undefined}>
              <input type="date" className="input" value={f.nextRevision} onChange={(e) => setF({ ...f, nextRevision: e.target.value })} />
            </Field>
            <Field label="Estimated remaining study time (min)">
              <input type="number" min={0} inputMode="numeric" className="input" value={f.est} onChange={(e) => setF({ ...f, est: e.target.value })} />
            </Field>
            <Field label="Actual study time (min)">
              <div className="flex gap-2">
                <input type="number" min={0} inputMode="numeric" className="input" value={f.actual} onChange={(e) => setF({ ...f, actual: e.target.value })} />
              </div>
            </Field>
          </div>
          <div className="flex items-end gap-2">
            <Field label="Quick add study time (min)" className="flex-1">
              <input type="number" min={1} inputMode="numeric" className="input" value={addMin} onChange={(e) => setAddMin(e.target.value)} placeholder="e.g. 30" />
            </Field>
            <Button
              onClick={() => {
                const n = toNum(addMin);
                if (n == null || n <= 0) return toast("Enter minutes greater than 0", "error");
                setF((x) => ({ ...x, actual: String(Math.round((toNum(x.actual) ?? 0) + n)), lastStudied: todayStr() }));
                setAddMin("");
                toast(`Added ${n} min — remember to save`, "info");
              }}
            >
              Add
            </Button>
          </div>
          <label className="flex min-h-10 items-center gap-2 text-sm">
            <input type="checkbox" className="h-4 w-4 accent-[var(--accent)]" checked={f.weakManual} onChange={(e) => setF({ ...f, weakManual: e.target.checked })} />
            Mark as a weak chapter
          </label>
        </section>

        {subject && subject.components.length > 0 && (
          <section>
            <h3 className="mb-2 text-sm font-semibold">Components</h3>
            <div className="flex flex-wrap gap-x-5 gap-y-1">
              {subject.components.map((c) => (
                <label key={c} className="flex min-h-10 items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    className="h-4 w-4 accent-[var(--accent)]"
                    checked={!!f.components[c]}
                    onChange={(e) => setF({ ...f, components: { ...f.components, [c]: e.target.checked } })}
                  />
                  {c}
                </label>
              ))}
            </div>
          </section>
        )}

        {kind === "math" && (
          <section className="space-y-3">
            <h3 className="text-sm font-semibold">Practice tracking</h3>
            <div className="grid grid-cols-3 gap-3">
              <Field label="Attempted">
                <input type="number" min={0} className="input" value={f.attempted} onChange={(e) => setF({ ...f, attempted: e.target.value })} />
              </Field>
              <Field label="Correct">
                <input type="number" min={0} className="input" value={f.correct} onChange={(e) => setF({ ...f, correct: e.target.value })} />
              </Field>
              <Field label="Difficult">
                <input type="number" min={0} className="input" value={f.difficult} onChange={(e) => setF({ ...f, difficult: e.target.value })} />
              </Field>
            </div>
            <Field label="Topics that need more practice">
              <textarea className="input" value={f.needsPractice} onChange={(e) => setF({ ...f, needsPractice: e.target.value })} />
            </Field>
          </section>
        )}

        <section className="space-y-3">
          <Field label="Study notes">
            <textarea className="input" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
          </Field>
          <Field label="Personal remarks">
            <textarea className="input" value={f.remarks} onChange={(e) => setF({ ...f, remarks: e.target.value })} />
          </Field>
        </section>

        <section>
          <h3 className="mb-2 text-sm font-semibold">Revisions ({revs.length})</h3>
          {revs.length === 0 ? (
            <p className="text-[13px] text-muted">None scheduled.</p>
          ) : (
            <ul className="space-y-1.5">
              {revs.map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-2 rounded-lg bg-surface2 px-3 py-2 text-[13px]">
                  <span>
                    {r.type} · {fmtDate(r.date)}
                  </span>
                  <Badge tone={r.done ? "ok" : r.date < todayStr() ? "bad" : "info"}>{r.done ? "Done" : r.date < todayStr() ? "Overdue" : "Scheduled"}</Badge>
                </li>
              ))}
            </ul>
          )}
        </section>
        <section>
          <h3 className="mb-2 text-sm font-semibold">Practice results ({prs.length})</h3>
          {prs.length === 0 ? (
            <p className="text-[13px] text-muted">No practice recorded for this chapter yet.</p>
          ) : (
            <ul className="space-y-1.5">
              {prs.slice(0, 5).map((p) => {
                const v = practicePct(p);
                return (
                  <li key={p.id} className="flex items-center justify-between gap-2 rounded-lg bg-surface2 px-3 py-2 text-[13px]">
                    <span>
                      {p.type} · {fmtDate(p.date)}
                    </span>
                    <span className="font-medium">{v != null ? `${v}%` : "logged"}</span>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
        <section>
          <h3 className="mb-2 text-sm font-semibold">Status history</h3>
          {chapter.history.length === 0 ? (
            <p className="text-[13px] text-muted">No status changes yet. History is kept even if the chapter later needs revision.</p>
          ) : (
            <ul className="space-y-1 text-[13px]">
              {[...chapter.history].reverse().map((h, i) => (
                <li key={i} className="flex items-center gap-2 text-muted">
                  <span>{new Date(h.date).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}</span>
                  <StatusBadge status={h.status} />
                </li>
              ))}
            </ul>
          )}
        </section>
        <p className="text-xs text-muted">
          Time logged: {fmtDuration(chapter.actualMin)} · Currently {statusLabel(chapter.status)} {chapter.lastStudied ? `· last studied ${fmtDate(chapter.lastStudied)}` : ""}
        </p>
      </div>
    </Modal>
  );
}
