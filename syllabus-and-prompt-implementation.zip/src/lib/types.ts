export type Status = "not_started" | "in_progress" | "completed" | "needs_revision";
export type Understanding = "very_weak" | "weak" | "average" | "good" | "excellent";
export type Priority = "low" | "medium" | "high";
export type SubjectKind = "math" | "science" | "language";

export const STATUSES: { value: Status; label: string }[] = [
  { value: "not_started", label: "Not Started" },
  { value: "in_progress", label: "In Progress" },
  { value: "completed", label: "Completed" },
  { value: "needs_revision", label: "Needs Revision" },
];

export const UNDERSTANDINGS: { value: Understanding; label: string; rank: number }[] = [
  { value: "very_weak", label: "Very Weak", rank: 1 },
  { value: "weak", label: "Weak", rank: 2 },
  { value: "average", label: "Average", rank: 3 },
  { value: "good", label: "Good", rank: 4 },
  { value: "excellent", label: "Excellent", rank: 5 },
];

export const PRIORITIES: { value: Priority; label: string; rank: number }[] = [
  { value: "high", label: "High", rank: 3 },
  { value: "medium", label: "Medium", rank: 2 },
  { value: "low", label: "Low", rank: 1 },
];

export const PRACTICE_TYPES = [
  "MCQs",
  "Short-answer questions",
  "Long-answer questions",
  "Textbook exercises",
  "Previous-year questions",
  "Mock test",
  "Other",
] as const;

export const TASK_TYPES = [
  "Study a new chapter",
  "Complete unfinished topics",
  "Practice questions",
  "Revise a chapter",
  "Take a mock test",
  "Review mistakes",
  "Other",
] as const;

export const REVISION_TYPES = ["First revision", "Second revision", "Third revision", "Final revision", "Quick revision", "Other"] as const;

export interface Subject {
  id: string;
  name: string;
  kind: SubjectKind;
  notes: string;
  /** Trackable components (e.g. Reading, Writing). Editable per subject. */
  components: string[];
}

export interface StatusLog {
  date: string; // ISO timestamp
  status: Status;
}

export interface MathPractice {
  attempted: number;
  correct: number;
  difficult: number;
  needsPractice: string;
}

export interface Chapter {
  id: string;
  subjectId: string;
  name: string;
  unit: string;
  subtopics: string[];
  status: Status;
  understanding: Understanding | null;
  priority: Priority;
  notes: string;
  remarks: string;
  lastStudied: string | null; // YYYY-MM-DD
  nextRevision: string | null; // YYYY-MM-DD
  estRemainingMin: number | null;
  actualMin: number;
  weakManual: boolean;
  components: Record<string, boolean>;
  math: MathPractice;
  history: StatusLog[];
  imported: boolean; // true when added through the syllabus import tool
  order: number;
}

export interface Task {
  id: string;
  date: string;
  start: string; // HH:MM or ""
  durationMin: number;
  subjectId: string;
  chapterId: string | null;
  type: string;
  description: string;
  priority: Priority;
  done: boolean;
  actualMin: number | null;
  notes: string;
}

export interface Revision {
  id: string;
  subjectId: string;
  chapterId: string;
  date: string;
  type: string;
  done: boolean;
  completedOn: string | null;
  difficulty: number | null; // 1-5
  notes: string;
}

export interface Practice {
  id: string;
  subjectId: string;
  chapterId: string | null;
  type: string;
  date: string;
  total: number | null;
  correct: number | null;
  incorrect: number | null;
  marks: number | null;
  totalMarks: number | null;
  timeMin: number | null;
  mistakes: string;
  notes: string;
}

export interface TimerLog {
  id: string;
  subjectId: string;
  chapterId: string | null;
  startedAt: string; // ISO
  durationSec: number;
  notes: string;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  subjectId: string | null;
  chapterId: string | null;
  createdAt: string;
  updatedAt: string;
}

export type EventKind = "deadline" | "important" | "mock";
export interface CalEvent {
  id: string;
  date: string;
  title: string;
  kind: EventKind;
  notes: string;
  done: boolean;
}

export interface Settings {
  theme: "light" | "dark";
  examDate: string | null;
  dailyTargetMin: number;
  pomodoro: { study: number; brk: number };
  revision: { suggest: boolean; intervals: number[] };
}

export interface TimerState {
  subjectId: string;
  chapterId: string | null;
  startedAt: string | null;
  studyMs: number;
  phaseMs: number;
  runningSince: number | null;
  pomodoro: boolean;
  phase: "study" | "break";
  active: boolean;
}

export interface AppData {
  version: 1;
  subjects: Subject[];
  chapters: Chapter[];
  tasks: Task[];
  revisions: Revision[];
  practice: Practice[];
  timerLogs: TimerLog[];
  notes: Note[];
  events: CalEvent[];
  settings: Settings;
  timer: TimerState;
}
