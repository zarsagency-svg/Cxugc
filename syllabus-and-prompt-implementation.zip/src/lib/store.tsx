"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type {
  AppData,
  CalEvent,
  Chapter,
  Note,
  Practice,
  Revision,
  Settings,
  Status,
  Subject,
  Task,
  TimerLog,
  TimerState,
} from "./types";
import { defaultTimer, newChapter, seedData, todayStr, uid, validateImport } from "./utils";

export const STORAGE_KEY = "hslc2027:v1";

type Updater = (d: AppData) => AppData;

export interface Actions {
  // chapters
  addChapter: (subjectId: string, name: string, extra?: Partial<Chapter>) => string;
  updateChapter: (id: string, patch: Partial<Chapter>) => void;
  setStatus: (id: string, status: Status) => void;
  deleteChapter: (id: string) => void;
  importChapters: (subjectId: string, items: { unit: string; name: string; subtopics: string[] }[], replace: boolean) => number;
  // subjects
  updateSubject: (id: string, patch: Partial<Subject>) => void;
  // tasks
  saveTask: (t: Omit<Task, "id"> & { id?: string }) => void;
  setTaskDone: (id: string, done: boolean, actualMin?: number | null) => void;
  deleteTask: (id: string) => void;
  // revisions
  saveRevision: (r: Omit<Revision, "id"> & { id?: string }) => void;
  completeRevision: (id: string, difficulty: number | null, notes?: string) => void;
  reopenRevision: (id: string) => void;
  deleteRevision: (id: string) => void;
  // practice
  savePractice: (p: Omit<Practice, "id"> & { id?: string }) => void;
  deletePractice: (id: string) => void;
  // timer
  setTimer: (patch: Partial<TimerState> | ((t: TimerState) => Partial<TimerState>)) => void;
  addTimerLog: (l: Omit<TimerLog, "id">) => void;
  deleteTimerLog: (id: string) => void;
  // notes & events
  saveNote: (n: Partial<Note> & { title: string; content: string }) => string;
  deleteNote: (id: string) => void;
  saveEvent: (e: Omit<CalEvent, "id"> & { id?: string }) => void;
  deleteEvent: (id: string) => void;
  // settings & data
  updateSettings: (patch: Partial<Settings>) => void;
  replaceAll: (d: AppData) => void;
  resetAll: () => void;
}

interface Store {
  data: AppData;
  ready: boolean;
  saveError: string | null;
  actions: Actions;
}

const Ctx = createContext<Store | null>(null);

export function useStore() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useStore must be used inside <StoreProvider>");
  return c;
}

function upsert<T extends { id: string }>(list: T[], item: Omit<T, "id"> & { id?: string }, prefix: string): T[] {
  if (item.id && list.some((x) => x.id === item.id)) {
    return list.map((x) => (x.id === item.id ? ({ ...x, ...item } as T) : x));
  }
  return [...list, { ...item, id: item.id ?? uid(prefix) } as T];
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(() => seedData());
  const [ready, setReady] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const hydrated = useRef(false);

  // hydrate from localStorage once on the client
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const res = validateImport(JSON.parse(raw));
        if (res.ok) setData(res.data);
        else setSaveError("Saved data could not be read and was ignored: " + res.error);
      } else if (window.matchMedia?.("(prefers-color-scheme: dark)").matches) {
        setData((d) => ({ ...d, settings: { ...d.settings, theme: "dark" } }));
      }
    } catch {
      setSaveError("Your browser blocked access to saved data (private mode or storage disabled). Changes may not persist.");
    }
    hydrated.current = true;
    setReady(true);
  }, []);

  // persist on every change
  useEffect(() => {
    if (!hydrated.current) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      setSaveError(null);
    } catch {
      setSaveError("Could not save to browser storage (it may be full or disabled). Export a backup from Settings.");
    }
  }, [data]);

  // theme class
  useEffect(() => {
    document.documentElement.classList.toggle("dark", data.settings.theme === "dark");
  }, [data.settings.theme]);

  const up = useCallback((fn: Updater) => setData((d) => fn(d)), []);

  const actions = useMemo<Actions>(() => {
    const touchChapter = (d: AppData, id: string, fn: (c: Chapter) => Chapter): AppData => ({
      ...d,
      chapters: d.chapters.map((c) => (c.id === id ? fn(c) : c)),
    });

    return {
      addChapter: (subjectId, name, extra = {}) => {
        const id = uid("ch");
        up((d) => {
          const order = d.chapters.filter((c) => c.subjectId === subjectId).length;
          return { ...d, chapters: [...d.chapters, { ...newChapter(subjectId, name, order, extra), id }] };
        });
        return id;
      },
      updateChapter: (id, patch) => up((d) => touchChapter(d, id, (c) => ({ ...c, ...patch }))),
      setStatus: (id, status) =>
        up((d) =>
          touchChapter(d, id, (c) => {
            if (c.status === status) return c;
            const today = todayStr();
            return {
              ...c,
              status,
              lastStudied: status === "in_progress" || status === "completed" ? today : c.lastStudied,
              history: [...c.history, { date: new Date().toISOString(), status }],
            };
          }),
        ),
      deleteChapter: (id) =>
        up((d) => ({
          ...d,
          chapters: d.chapters.filter((c) => c.id !== id),
          revisions: d.revisions.filter((r) => r.chapterId !== id),
          tasks: d.tasks.map((t) => (t.chapterId === id ? { ...t, chapterId: null } : t)),
          practice: d.practice.map((p) => (p.chapterId === id ? { ...p, chapterId: null } : p)),
          notes: d.notes.map((n) => (n.chapterId === id ? { ...n, chapterId: null } : n)),
          timerLogs: d.timerLogs.map((l) => (l.chapterId === id ? { ...l, chapterId: null } : l)),
        })),
      importChapters: (subjectId, items, replace) => {
        let added = 0;
        up((d) => {
          let chapters = d.chapters;
          if (replace) chapters = chapters.filter((c) => c.subjectId !== subjectId);
          const existing = new Set(chapters.filter((c) => c.subjectId === subjectId).map((c) => c.name.trim().toLowerCase()));
          let order = chapters.filter((c) => c.subjectId === subjectId).length;
          const fresh: Chapter[] = [];
          for (const it of items) {
            const key = it.name.trim().toLowerCase();
            if (!key || existing.has(key)) continue; // avoid duplicates
            existing.add(key);
            fresh.push(newChapter(subjectId, it.name.trim(), order++, { unit: it.unit, subtopics: it.subtopics, imported: true }));
          }
          added = fresh.length;
          return { ...d, chapters: [...chapters, ...fresh] };
        });
        return added;
      },
      updateSubject: (id, patch) => up((d) => ({ ...d, subjects: d.subjects.map((s) => (s.id === id ? { ...s, ...patch } : s)) })),

      saveTask: (t) => up((d) => ({ ...d, tasks: upsert(d.tasks, t, "task") })),
      setTaskDone: (id, done, actualMin) =>
        up((d) => ({
          ...d,
          tasks: d.tasks.map((t) =>
            t.id === id ? { ...t, done, actualMin: done ? (actualMin !== undefined ? actualMin : t.actualMin ?? t.durationMin) : null } : t,
          ),
        })),
      deleteTask: (id) => up((d) => ({ ...d, tasks: d.tasks.filter((t) => t.id !== id) })),

      saveRevision: (r) => up((d) => ({ ...d, revisions: upsert(d.revisions, r, "rev") })),
      completeRevision: (id, difficulty, notes) =>
        up((d) => {
          const rev = d.revisions.find((r) => r.id === id);
          if (!rev) return d;
          const today = todayStr();
          const next = {
            ...d,
            revisions: d.revisions.map((r) =>
              r.id === id ? { ...r, done: true, completedOn: today, difficulty, notes: notes ?? r.notes } : r,
            ),
          };
          return touchChapter(next, rev.chapterId, (c) => ({ ...c, lastStudied: today }));
        }),
      reopenRevision: (id) =>
        up((d) => ({ ...d, revisions: d.revisions.map((r) => (r.id === id ? { ...r, done: false, completedOn: null } : r)) })),
      deleteRevision: (id) => up((d) => ({ ...d, revisions: d.revisions.filter((r) => r.id !== id) })),

      savePractice: (p) => up((d) => ({ ...d, practice: upsert(d.practice, p, "pr") })),
      deletePractice: (id) => up((d) => ({ ...d, practice: d.practice.filter((p) => p.id !== id) })),

      setTimer: (patch) =>
        up((d) => ({ ...d, timer: { ...d.timer, ...(typeof patch === "function" ? patch(d.timer) : patch) } })),
      addTimerLog: (l) =>
        up((d) => {
          const logs = [...d.timerLogs, { ...l, id: uid("tl") }];
          if (!l.chapterId) return { ...d, timerLogs: logs };
          const mins = Math.round(l.durationSec / 60);
          return touchChapter({ ...d, timerLogs: logs }, l.chapterId, (c) => ({
            ...c,
            actualMin: c.actualMin + mins,
            lastStudied: todayStr(),
          }));
        }),
      deleteTimerLog: (id) => up((d) => ({ ...d, timerLogs: d.timerLogs.filter((l) => l.id !== id) })),

      saveNote: (n) => {
        const id = n.id ?? uid("note");
        const now = new Date().toISOString();
        up((d) => {
          const exists = d.notes.find((x) => x.id === id);
          if (exists) {
            return { ...d, notes: d.notes.map((x) => (x.id === id ? { ...x, ...n, id, updatedAt: now } : x)) };
          }
          const note: Note = {
            id,
            title: n.title,
            content: n.content,
            subjectId: n.subjectId ?? null,
            chapterId: n.chapterId ?? null,
            createdAt: now,
            updatedAt: now,
          };
          return { ...d, notes: [note, ...d.notes] };
        });
        return id;
      },
      deleteNote: (id) => up((d) => ({ ...d, notes: d.notes.filter((n) => n.id !== id) })),

      saveEvent: (e) => up((d) => ({ ...d, events: upsert(d.events, e, "ev") })),
      deleteEvent: (id) => up((d) => ({ ...d, events: d.events.filter((e) => e.id !== id) })),

      updateSettings: (patch) => up((d) => ({ ...d, settings: { ...d.settings, ...patch } })),
      replaceAll: (nd) => setData({ ...nd, timer: nd.timer ?? defaultTimer() }),
      resetAll: () => {
        const fresh = seedData();
        fresh.settings.theme = "light";
        setData(fresh);
      },
    };
  }, [up]);

  const value = useMemo(() => ({ data, ready, saveError, actions }), [data, ready, saveError, actions]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
