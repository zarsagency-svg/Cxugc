import type {
  AppData,
  Chapter,
  Practice,
  Priority,
  Revision,
  Settings,
  Status,
  Subject,
  TimerState,
  Understanding,
} from "./types";
import { PRIORITIES, STATUSES, UNDERSTANDINGS } from "./types";

/* ---------- ids & numbers ---------- */
export const uid = (p = "id") => `${p}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
export const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n));
export const toNum = (v: string): number | null => {
  if (v.trim() === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

/* ---------- dates (always local time) ---------- */
const p2 = (n: number) => String(n).padStart(2, "0");
export const dateStr = (d: Date) => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
export const todayStr = () => dateStr(new Date());
export const parseDate = (s: string) => {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
};
export const addDays = (s: string, n: number) => {
  const d = parseDate(s);
  d.setDate(d.getDate() + n);
  return dateStr(d);
};
export const startOfWeek = (s: string) => {
  const d = parseDate(s);
  const diff = (d.getDay() + 6) % 7; // Monday start
  d.setDate(d.getDate() - diff);
  return dateStr(d);
};
export const diffDays = (a: string, b: string) =>
  Math.round((parseDate(a).getTime() - parseDate(b).getTime()) / 86400000);
export const fmtDate = (s: string | null | undefined, opts?: Intl.DateTimeFormatOptions) =>
  s ? parseDate(s).toLocaleDateString(undefined, opts ?? { day: "numeric", month: "short", year: "numeric" }) : "—";
export const fmtShort = (s: string | null | undefined) =>
  s ? parseDate(s).toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" }) : "—";
export const fmtTime = (t: string) => {
  if (!t) return "";
  const [h, m] = t.split(":").map(Number);
  const d = new Date();
  d.setHours(h, m, 0, 0);
  return d.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
};
export const fmtDuration = (min: number) => {
  const m = Math.max(0, Math.round(min));
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  const r = m % 60;
  return r ? `${h}h ${r}m` : `${h}h`;
};
export const fmtClock = (ms: number) => {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${h > 0 ? p2(h) + ":" : ""}${p2(m)}:${p2(s % 60)}`;
};
export const isoToLocalDate = (iso: string) => dateStr(new Date(iso));

/* ---------- labels ---------- */
export const statusLabel = (s: Status) => STATUSES.find((x) => x.value === s)?.label ?? s;
export const understandingLabel = (u: Understanding | null) =>
  u ? UNDERSTANDINGS.find((x) => x.value === u)?.label ?? u : "Not rated";
export const priorityLabel = (p: Priority) => PRIORITIES.find((x) => x.value === p)?.label ?? p;
export const priorityRank = (p: Priority) => PRIORITIES.find((x) => x.value === p)?.rank ?? 0;
export const understandingRank = (u: Understanding | null) => UNDERSTANDINGS.find((x) => x.value === u)?.rank ?? 0;

/* ---------- practice maths ---------- */
/** Returns a 0-100 percentage or null when it cannot be computed safely. */
export function practicePct(p: Pick<Practice, "marks" | "totalMarks" | "correct" | "total">): number | null {
  if (p.marks != null && p.totalMarks != null && p.totalMarks > 0) {
    return Math.round(clamp((p.marks / p.totalMarks) * 100, 0, 100) * 10) / 10;
  }
  if (p.correct != null && p.total != null && p.total > 0) {
    return Math.round(clamp((p.correct / p.total) * 100, 0, 100) * 10) / 10;
  }
  return null;
}

export function pct(done: number, total: number) {
  if (!total || total <= 0) return 0;
  return Math.round(clamp((done / total) * 100, 0, 100));
}

/* ---------- weak chapters ---------- */
export function weakReasons(ch: Chapter, practice: Practice[]): string[] {
  const r: string[] = [];
  if (ch.understanding === "very_weak") r.push("Understanding: Very Weak");
  if (ch.understanding === "weak") r.push("Understanding: Weak");
  if (ch.weakManual) r.push("Marked weak by you");
  if (ch.status === "needs_revision") r.push("Needs Revision");
  const scores = practice
    .filter((p) => p.chapterId === ch.id)
    .sort((a, b) => (a.date < b.date ? 1 : -1))
    .map((p) => practicePct(p))
    .filter((x): x is number => x != null)
    .slice(0, 2);
  if (scores.length >= 2) {
    const avg = (scores[0] + scores[1]) / 2;
    if (avg < 50) r.push(`Recent practice average ${Math.round(avg)}%`);
  }
  return r;
}

export function latestPractice(chapterId: string, practice: Practice[]) {
  return practice
    .filter((p) => p.chapterId === chapterId && practicePct(p) != null)
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : 0))[0];
}

/* ---------- stats ---------- */
export function subjectStats(subjectId: string, chapters: Chapter[]) {
  const list = chapters.filter((c) => c.subjectId === subjectId);
  const count = (s: Status) => list.filter((c) => c.status === s).length;
  const total = list.length;
  const completed = count("completed");
  return {
    total,
    completed,
    inProgress: count("in_progress"),
    notStarted: count("not_started"),
    needsRevision: count("needs_revision"),
    remaining: total - completed,
    percent: pct(completed, total),
  };
}

export function overallStats(chapters: Chapter[]) {
  const total = chapters.length;
  const count = (s: Status) => chapters.filter((c) => c.status === s).length;
  const completed = count("completed");
  return {
    total,
    completed,
    inProgress: count("in_progress"),
    notStarted: count("not_started"),
    needsRevision: count("needs_revision"),
    percent: pct(completed, total),
  };
}

/** Earliest pending scheduled revision, falling back to the manually entered date. */
export function nextRevisionOf(ch: Chapter, revisions: Revision[]): string | null {
  const pending = revisions.filter((r) => r.chapterId === ch.id && !r.done).map((r) => r.date).sort()[0];
  return pending ?? ch.nextRevision;
}

export function revisionBucket(r: Revision, today: string): "done" | "overdue" | "today" | "upcoming" {
  if (r.done) return "done";
  if (r.date < today) return "overdue";
  if (r.date === today) return "today";
  return "upcoming";
}

/* ---------- seed / defaults ---------- */
export const SUBJECT_NAMES: { id: string; name: string; kind: Subject["kind"]; components: string[] }[] = [
  { id: "gen-math", name: "General Mathematics", kind: "math", components: [] },
  { id: "adv-math", name: "Advanced Mathematics", kind: "math", components: [] },
  { id: "gen-sci", name: "General Science", kind: "science", components: ["Chapter reading", "Written answers", "Practice questions"] },
  { id: "soc-sci", name: "Social Science", kind: "science", components: ["Chapter reading", "Written answers", "Practice questions"] },
  { id: "assamese", name: "Assamese (MIL)", kind: "language", components: [] },
  { id: "english", name: "English (Second Language)", kind: "language", components: [] },
];

export const defaultSettings = (): Settings => ({
  theme: "light",
  examDate: null,
  dailyTargetMin: 180,
  pomodoro: { study: 25, brk: 5 },
  revision: { suggest: true, intervals: [1, 3, 7, 14] },
});

export const defaultTimer = (): TimerState => ({
  subjectId: "",
  chapterId: null,
  startedAt: null,
  studyMs: 0,
  phaseMs: 0,
  runningSince: null,
  pomodoro: false,
  phase: "study",
  active: false,
});

export function seedData(): AppData {
  return {
    version: 1,
    subjects: SUBJECT_NAMES.map((s) => ({ id: s.id, name: s.name, kind: s.kind, notes: "", components: [...s.components] })),
    chapters: [],
    tasks: [],
    revisions: [],
    practice: [],
    timerLogs: [],
    notes: [],
    events: [],
    settings: defaultSettings(),
    timer: defaultTimer(),
  };
}

export function newChapter(subjectId: string, name: string, order: number, extra: Partial<Chapter> = {}): Chapter {
  return {
    id: uid("ch"),
    subjectId,
    name,
    unit: "",
    subtopics: [],
    status: "not_started",
    understanding: null,
    priority: "medium",
    notes: "",
    remarks: "",
    lastStudied: null,
    nextRevision: null,
    estRemainingMin: null,
    actualMin: 0,
    weakManual: false,
    components: {},
    math: { attempted: 0, correct: 0, difficult: 0, needsPractice: "" },
    history: [],
    imported: false,
    order,
    ...extra,
  };
}

/**
 * Parse pasted syllabus text. Format (forgiving):
 *   Unit/Section lines:   "UNIT: Algebra"  or  "# Algebra"
 *   Chapter lines:        any other line (leading numbering / bullets are stripped)
 *   Subtopics:            lines indented with spaces/tab or starting with "-" / "•" / "*" after a chapter
 */
export function parseSyllabusText(text: string): { unit: string; name: string; subtopics: string[] }[] {
  const out: { unit: string; name: string; subtopics: string[] }[] = [];
  let unit = "";
  for (const raw of text.split(/\r?\n/)) {
    if (!raw.trim()) continue;
    const line = raw.trim();
    const unitMatch = line.match(/^(?:unit|section|part)\s*[:\-–]\s*(.+)$/i) || line.match(/^#+\s*(.+)$/);
    if (unitMatch) {
      unit = unitMatch[1].trim();
      continue;
    }
    const isSub = /^\s{2,}\S|^\t/.test(raw) || /^[-•*–]\s+/.test(line);
    const cleaned = line.replace(/^[-•*–]\s+/, "").replace(/^(?:chapter\s*)?\d+[.)\]:-]?\s+/i, "").trim();
    if (!cleaned) continue;
    if (isSub && out.length) {
      out[out.length - 1].subtopics.push(cleaned);
    } else {
      out.push({ unit, name: cleaned, subtopics: [] });
    }
  }
  return out;
}

/* ---------- import validation ---------- */
export function validateImport(raw: unknown): { ok: true; data: AppData } | { ok: false; error: string } {
  if (!raw || typeof raw !== "object") return { ok: false, error: "File is not a valid backup object." };
  const o = raw as Record<string, unknown>;
  const src = (o.data && typeof o.data === "object" ? o.data : o) as Record<string, unknown>;
  if (src.version !== 1) return { ok: false, error: "Unrecognised backup version." };
  const arrays = ["subjects", "chapters", "tasks", "revisions", "practice", "timerLogs", "notes", "events"] as const;
  for (const k of arrays) {
    if (!Array.isArray(src[k])) return { ok: false, error: `Backup is missing the "${k}" list.` };
  }
  if (!src.settings || typeof src.settings !== "object") return { ok: false, error: "Backup is missing settings." };
  const subjects = src.subjects as Subject[];
  if (subjects.some((s) => !s || typeof s.id !== "string" || typeof s.name !== "string"))
    return { ok: false, error: "Backup contains an invalid subject entry." };
  const chapters = src.chapters as Chapter[];
  if (chapters.some((c) => !c || typeof c.id !== "string" || typeof c.name !== "string" || typeof c.subjectId !== "string"))
    return { ok: false, error: "Backup contains an invalid chapter entry." };
  const base = seedData();
  const data: AppData = {
    ...base,
    ...(src as unknown as AppData),
    settings: { ...base.settings, ...(src.settings as Settings) },
    timer: { ...base.timer, ...((src.timer as TimerState) ?? {}) },
  };
  data.chapters = data.chapters.map((c) => ({ ...newChapter(c.subjectId, c.name, c.order ?? 0), ...c }));
  return { ok: true, data };
}

export function download(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 500);
}

export function csvCell(v: unknown) {
  const s = v == null ? "" : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
